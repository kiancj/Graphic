package io.github.some_example_name.model;

public class GameColors {
}
