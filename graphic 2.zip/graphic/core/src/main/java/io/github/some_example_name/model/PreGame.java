package io.github.some_example_name.model;

public class PreGame {
    private String hero;
    private int duration;
}
