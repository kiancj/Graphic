package io.github.some_example_name.model;


import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.model.GameAssetManger;

public class BossEnemy {
    private Sprite sprite;
    private Vector2 position;
    private CollisionRect collisionRect;
    private int health = 400;
    private boolean isDashing = false;
    private Vector2 dashTarget;
    private final float dashSpeed = 300f;
    // adjust as needed
    private boolean dying = false;
    private float deathAnimationTimer = 0f;
    private float deathAnimationDuration = 2f;
    private boolean alive = true;
    public enum BossState { IDLE, DASHING , MOVING }
    private Animation<Texture> deathAnimation = GameAssetManger.getGameAssetManager().getDeath_frame();

    private BossState state = BossState.IDLE;
    private float animationTimer = 0f;


    public void setState(BossState newState) {
        if (this.state != newState) {
            this.state = newState;
            this.animationTimer = 0f; // reset animation time when changing state
        }
    }

    public boolean isDying() {
        return dying;
    }

    // Start dying animation
    public void die() {
        dying = true;
        alive = false; // no longer alive, but still present for animation
        deathAnimationTimer = 0f;
    }
    public boolean shouldBeRemoved() {
        return dying && deathAnimationTimer >= deathAnimationDuration;
    }

    // Modify takeDamage to trigger die animation instead of immediate removal

    public BossState getState() {
        return state;
    }



    public float getAnimationTimer() {
        return animationTimer;
    }

    public BossEnemy(float x, float y) {
        Texture texture = new Texture(GameAssetManger.getGameAssetManager().getboss()); // Add boss texture
        this.sprite = new Sprite(texture);
        sprite.setSize(100, 100); // Adjust size if needed
        this.position = new Vector2(x, y);
        this.collisionRect = new CollisionRect(x, y, sprite.getWidth(), sprite.getHeight());
    }

    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            alive = false;
            dying = true;
        }
    }

    public boolean isAlive() {
        return alive;
    }

    public void update(float delta) {
        animationTimer += delta;
        if (state == BossState.DASHING) {
            if (dashTarget != null) {
                Vector2 direction = dashTarget.cpy().sub(position).nor();
                float distance = dashSpeed * delta;
                Vector2 move = direction.scl(distance);

                if (position.dst(dashTarget) <= distance) {
                    position.set(dashTarget); // reached
                    setState(BossState.MOVING);
                } else {
                    position.add(move);
                }
            }

        }

        sprite.setPosition(position.x, position.y);
        collisionRect.move(position.x, position.y);
    }



    public void moveBy(Vector2 offset) {
        position.add(offset);
    }

    public Sprite getSprite() {
        return sprite;
    }

    public CollisionRect getCollisionRect() {
        return collisionRect;
    }

    public Vector2 getPosition() {
        return position;
    }
    public void startDash(Vector2 target) {
        this.dashTarget = target;
        setState(BossState.DASHING);
    }
    public void updateDeathAnimation(float delta) {
        if (dying) {
            deathAnimationTimer += delta;
        }
    }
    public Texture getCurrentDeathFrame() {
        return deathAnimation.getKeyFrame(deathAnimationTimer, false);
    }
}

