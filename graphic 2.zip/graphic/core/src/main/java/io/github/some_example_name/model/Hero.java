package io.github.some_example_name.model;

public enum Hero {
    SHANA("Shana", 4, 4),
    DIAMOND("Diamond", 7, 1),
    SCARLET("Scarlet", 3, 5),
    LILITH("Lilith", 5, 3),
    DASHER("Dasher", 2, 10);

    private final String displayName;
    private final int hp;
    private final int speed;

    Hero(String displayName, int hp, int speed) {
        this.displayName = displayName;
        this.hp = hp;
        this.speed = speed;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getHp() {
        return hp;
    }

    public int getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return displayName + " (HP: " + hp + ", Speed: " + speed + ")";
    }
}

