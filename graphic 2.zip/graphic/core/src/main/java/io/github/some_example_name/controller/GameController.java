package io.github.some_example_name.controller;


import com.badlogic.gdx.Gdx;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;
import io.github.some_example_name.view.EndMenuView;
import io.github.some_example_name.view.GameView;


public class GameController {
    private GameView view;
    private PlayerController playerController;
    private WorldController worldController;
    private WeaponController weaponController;
    private EnemyController enemyController;
    private ShooterEnemyController shooterEnemyController;
    private BossEnemyController bossEnemyController;
    TreeController treeController;



    public void setView(GameView view) {
        this.view = view;
        Player player = App.getCurrentPlayer();
        playerController = new PlayerController(player);
        worldController = new WorldController(playerController);
        treeController = new TreeController(playerController);
        weaponController = new WeaponController(new Weapon());
        bossEnemyController = new BossEnemyController(playerController , weaponController , this);
        shooterEnemyController = new ShooterEnemyController(playerController ,weaponController);
        enemyController = new EnemyController(playerController, weaponController);
    }

    public void updateGame() {
        Player player = App.getCurrentPlayer();
        if(player.getPlayerHealth() < 0){
            player.setWin(false);
            Main.getMain().setScreen(new EndMenuView(new EndMenuController() , GameAssetManger.getGameAssetManager().getSkin(), view.getTotalPlayTime()));
        }
        if (view != null) {

            worldController.update();
            enemyController.update(Gdx.graphics.getDeltaTime());
            shooterEnemyController.update(Gdx.graphics.getDeltaTime());
            bossEnemyController.update(Gdx.graphics.getDeltaTime(), Main.getBatch());
            treeController.update(Gdx.graphics.getDeltaTime());
            playerController.update();
            weaponController.update();

        }
    }

    public PlayerController getPlayerController() {
        return playerController;
    }

    public WeaponController getWeaponController() {
        return weaponController;
    }
    public EnemyController getEnemyController(){
        return enemyController;
    }

    public GameView getView() {
        return view;
    }
}
