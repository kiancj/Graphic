package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.*;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.Player;
import io.github.some_example_name.model.Weapon;




public class GameView implements Screen, InputProcessor {
    private Stage stage;
    private GameController controller;
    private BitmapFont font;
    private ShapeRenderer shapeRenderer;
    private PauseMenuView pauseMenuView;
    private PauseMenuController pauseController;
    private float totalPlayTime = 0f;
    private long lastUpdateTime = 0;
    private int lastLevel;
    private AbilityWindowController abilityController;
    private AbilityWindowView abilityView;
    private float remainingTime = App.getCurrentPlayer().getTime();





    public GameView(GameController controller, Skin skin) {
        this.controller = controller;
        lastLevel = App.getCurrentPlayer().getLevel();
        controller.setView(this);
        pauseMenuView = new PauseMenuView();
        pauseController = new PauseMenuController(
            pauseMenuView,
            () -> pauseController.setPaused(false), // Resume
            () -> { Main.getMain().setScreen(new MainMenuView(new MainMenuController(),GameAssetManger.getGameAssetManager().getSkin())); },
            () -> {
                App.getCurrentPlayer().setWin(false);
                Main.getMain().setScreen(new EndMenuView(new EndMenuController() , GameAssetManger.getGameAssetManager().getSkin(), totalPlayTime));
            },
            this // Input processor
        );
        abilityView = new AbilityWindowView();
        abilityController = new AbilityWindowController(
            abilityView,
            () -> {
                abilityController.setAbilityWindowActive(false);
            },
            this
        );

// Pause game

// Show view


    }

    @Override
    public void show() {
        setCustomCursor(GameAssetManger.getGameAssetManager().getCursor(), 0, 0);
        stage = new Stage(new ScreenViewport());
        font = new BitmapFont(); // Default font
        shapeRenderer = new ShapeRenderer();
        font.getData().setScale(2f); // Optional: make the text bigger
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void render(float delta) {
        if(remainingTime  <=  0 ){
            App.getCurrentPlayer().setWin(true);
            Main.getMain().setScreen(new EndMenuView(new EndMenuController() , GameAssetManger.getGameAssetManager().getSkin(), totalPlayTime));

        }
        ScreenUtils.clear(35 / 255f, 29 / 255f, 42 / 255f, 1);
        pauseController.update();
        Main.getBatch().begin();
        if (pauseController.isPaused()) {
            pauseMenuView.draw();
            setActiveAbilities();
            Main.getBatch().end();// draw pause overlay
            return;
        }
        if (lastLevel < App.getCurrentPlayer().getLevel() && !abilityController.isAbilityWindowActive()) {
            abilityController.setAbilityWindowActive(true);
            if(App.getCurrentUser().isSfxActive()){
                GameAssetManger.getGameAssetManager().getLevelUp().play();
            }
            lastLevel = App.getCurrentPlayer().getLevel();
            Main.getBatch().end(); // ✅ ADD THIS
            return;
        }

        if (abilityController.isAbilityWindowActive()) {
            abilityView.draw();
            Main.getBatch().end(); // ✅ ADD THIS
            return;
        }

        // 🕒 Update game logic and time
            controller.updateGame();
            remainingTime -= delta;
            totalPlayTime += delta;

        font.setColor(Color.WHITE);
        font.draw(Main.getBatch(),
            "Health: " + (int)controller.getPlayerController().getPlayer().getPlayerHealth(),
            20, 460); // X and Y position on screen
            font.draw(Main.getBatch(),
                "Kill: "+ (int)controller.getPlayerController().getPlayer().getKill(),
                20,400
                );
        font.draw(Main.getBatch(),
            "Level: "+ (int)controller.getPlayerController().getPlayer().getLevel(),
            20,520
        );
        font.draw(Main.getBatch(),
            "Ammo: "+ (int)controller.getWeaponController().getWeapon().getAmmo()+"/"+(int)controller.getWeaponController().getWeapon().getMaxAmmo(),
            20,350
        );
        font.draw(Main.getBatch(),
            "Level Process: ",
            20,640
        );
        int minutes = (int)(remainingTime / 60);
        int seconds = (int)(remainingTime % 60);
        String timeString = String.format("Time: %02d:%02d", minutes, seconds);
        font.draw(Main.getBatch(), timeString, 20, 300);
        Main.getBatch().end();
        // 🎯 XP Progress Bar
        int barX = 20;
        int barY = 580;
        int barWidth = 200;
        int barHeight = 20;

// Get XP info from player
        int currentXp = controller.getPlayerController().getPlayer().getXp();
        int xpToLevel = controller.getPlayerController().getPlayer().getXpToNextLevel(); // You must have this method
        float progress = Math.min((float) currentXp / xpToLevel, 1f); // Clamp to 1.0

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

// Background bar
        shapeRenderer.setColor(Color.DARK_GRAY);
        shapeRenderer.rect(barX, barY, barWidth, barHeight);

// Fill bar
        shapeRenderer.setColor(Color.GREEN);
        shapeRenderer.rect(barX, barY, barWidth * progress, barHeight);

        shapeRenderer.end();

        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
    }

    @Override
    public boolean keyDown(int keycode) {
        /// p for reducing game time
        /// l for leveling up
        /// H for getting more health
        /// U for increasing speed
        if (keycode == Input.Keys.R) {
            Weapon weapon = controller.getWeaponController().getWeapon();
            if (!weapon.isReloading() && weapon.getAmmo() < weapon.getMaxAmmo()) {
                weapon.setReloading(true);
                weapon.setReloadTimer(0f);
            }
        }
        else if(keycode == Input.Keys.P){
            remainingTime -= 60f;
            totalPlayTime += 60f;
        }
//        else if(keycode == Input.Keys.B){
//           App.getCurrentPlayer().setSpawnBoss(true);
//        }
        else if(keycode == Input.Keys.L){
            App.getCurrentPlayer().increaseLevel();
        }
        else if((keycode == Input.Keys.H) && (App.getCurrentPlayer().getPlayerHealth() == 0)){
            App.getCurrentPlayer().increaseHealth();
        }
        else if(keycode == Input.Keys.U){
            App.getCurrentPlayer().increaseSpeed();
        }
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {

        controller.getWeaponController().handleWeaponShoot(screenX, screenY);
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        controller.getWeaponController().handleWeaponRotation(screenX, screenY);
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }
    private void setCustomCursor(String imagePath, int xHotspot, int yHotspot) {
        Pixmap pixmap = new Pixmap(Gdx.files.internal(imagePath));
        Cursor cursor = Gdx.graphics.newCursor(pixmap, xHotspot, yHotspot);
        Gdx.graphics.setCursor(cursor);
        pixmap.dispose();
    }
    public float getTotalPlayTime() {
        return totalPlayTime;
    }
    private void setActiveAbilities() {
        Array<String> abilities = new Array<>();
        Player player = App.getCurrentPlayer();

        if (player.isAbilityActiveDamage()) {
            abilities.add("DAMAGER ");
        }
        if (player.isAbilityActiveSpeed()) {
            abilities.add("SPEED ");
        }
        if (player.isAmocreaseActive()) {
            abilities.add("AMOCREASE ");
        }
        if (player.isProcreaseActive()) {
            abilities.add("PROCREASE ");
        }
        if (player.isVitalityActive()) {
            abilities.add("VITALITY ");
        }

        if (abilities.size > 0) {
            pauseMenuView.getActiveAbilities().setText("Active Abilities: " + String.join(", ", abilities.toArray(String.class)));
        } else {
            pauseMenuView.getActiveAbilities().setText("No Active Abilities");
        }
    }

    public float getRemainingTime() {
        return remainingTime;
    }
}
