package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.Player;

public class PauseMenuView {
    private final Stage stage;
    private final Skin skin;
    private final Window window;

    private final TextButton resumeButton;
    private final TextButton mainMenuButton;
    private final TextButton exitButton;
    private final Label cheatCode1;
    private final Label cheatCode2;
    private final Label activeAbilities;

    public PauseMenuView() {
        stage = new Stage(new ScreenViewport());
        skin = GameAssetManger.getGameAssetManager().getSkin();
        activeAbilities = new Label("",skin);
        window = new Window("Paused", skin);
        cheatCode1 = new Label("U : increase speed , L : increase level ",skin);
        cheatCode2 = new Label("H : get hp , P : for decreasing game time",skin);
        window.setModal(true);
        window.setMovable(false);
        window.setResizable(false);
        window.setSize(800, 1000);
        window.setPosition(
            (Gdx.graphics.getWidth() - window.getWidth()) / 2f,
            (Gdx.graphics.getHeight() - window.getHeight()) / 2f
        );

        resumeButton = new TextButton("Resume", skin);
        mainMenuButton = new TextButton("Main Menu", skin);
        exitButton = new TextButton("Give Up", skin);

        window.add(resumeButton).width(200).pad(10).row();
        window.add(mainMenuButton).width(200).pad(10).row();
        window.add(exitButton).width(200).pad(10).row();
        window.add(cheatCode1).row();
        window.add(cheatCode2).row();
        window.add(activeAbilities).row();
        stage.addActor(window);
    }

    public void draw() {
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }

    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    public void dispose() {
        stage.dispose();
        skin.dispose();
    }

    public Stage getStage() {
        return stage;
    }

    public TextButton getResumeButton() {
        return resumeButton;
    }

    public TextButton getMainMenuButton() {
        return mainMenuButton;
    }

    public TextButton getExitButton() {
        return exitButton;
    }

    public Window getWindow() {
        return window;
    }

    public Label getActiveAbilities() {
        return activeAbilities;
    }


}
