package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;

import java.util.ArrayList;
import java.util.Iterator;

public class BossEnemyController {
    private BossEnemy boss;
    private final PlayerController playerController;
    private final WeaponController weaponController;
    private final GameController gameController;
    private boolean spawned = false;
    private float dashTimer = 0f;
    private final float dashInterval = 5f;
    private final float dashSpeed = 600f;
    private final float moveSpeed = 20f;
    private final float damageCooldownTime = 1f;
    private float damageCooldown = 0f;

    private ArrayList<XpDot> xpDots = new ArrayList<>();
    private boolean bossDying = false;

    public BossEnemyController(PlayerController playerController, WeaponController weaponController, GameController gameController) {
        this.playerController = playerController;
        this.weaponController = weaponController;
        this.gameController = gameController;
    }


    // ... existing fields ...

    public void update(float delta, SpriteBatch batch) {
        if (!spawned && gameController.getView().getTotalPlayTime() >= gameController.getView().getRemainingTime() || playerController.getPlayer().isSpawnBoss()) {
            float px = playerController.getPlayer().getPosX();
            float py = playerController.getPlayer().getPosY();
            boss = new BossEnemy(px + 300, py + 300);
            spawned = true;
        }
        if (!spawned) return;
        if(boss == null){
            return;
        }
        // Handle death animation and removal
        if (!boss.isAlive() && boss.isDying()) {
            boss.updateDeathAnimation(delta);
            playerController.getPlayer().increaseLevel();
            playerController.getPlayer().increaseKill(5);
            Vector2 screenPos = worldToScreen(boss.getPosition(), playerController.getPlayer());
            batch.draw(boss.getCurrentDeathFrame(), screenPos.x, screenPos.y);

            // ✅ Wait until death animation is done
            if (boss.shouldBeRemoved()) {
                if (App.getCurrentUser().isSfxActive()) {
                    GameAssetManger.getGameAssetManager().getEnemyKilled().play();
                }

                // Now drop XP and remove the boss
                xpDots.add(new XpDot(boss.getPosition().x, boss.getPosition().y));
                boss = null;
            }

            // Update XP dots even while boss is dying
            updateXpDots(delta, batch);
            return;
        }


        if (!boss.isAlive()) return; // boss dead and no death animation to play

        dashTimer += delta;
        damageCooldown -= delta;
        //moveTowardPlayer(delta);
        if (dashTimer >= dashInterval) {
            dashTowardPlayer();
            dashTimer = 0f;
        }

        boss.update(delta);
        checkBulletCollision(boss);
        checkPlayerCollision();

        Vector2 screenPos = worldToScreen(boss.getPosition(), playerController.getPlayer());
        Animation<Texture> currentAnimation = boss.getState() == BossEnemy.BossState.DASHING
            ? GameAssetManger.getGameAssetManager().getBossAnimation()
            : GameAssetManger.getGameAssetManager().getBoss();

        Texture frame = currentAnimation.getKeyFrame(boss.getAnimationTimer(), true);
        batch.draw(frame, screenPos.x, screenPos.y);


    }

    private void updateXpDots(float delta, SpriteBatch batch) {
        Iterator<XpDot> xpIterator = xpDots.iterator();
        while (xpIterator.hasNext()) {
            XpDot dot = xpIterator.next();

            dot.updateCollisionRect();
            if (dot.getCollisionRect().collidesWith(playerController.getPlayer().getRect())) {
                if (App.getCurrentUser().isSfxActive()) {
                    GameAssetManger.getGameAssetManager().getCoins().play();
                }
                dot.collect();
                playerController.getPlayer().addXp(10); // Boss can give more XP, adjust as needed
                xpIterator.remove();
            } else {
                dot.draw(Main.getBatch(), playerController.getPlayer().getPosX(), playerController.getPlayer().getPosY());
            }
        }
    }



    private void moveTowardPlayer(float delta) {
        if (boss == null || !boss.isAlive()) return;
        boss.setState(BossEnemy.BossState.MOVING);
        Vector2 bossPos = boss.getPosition();
        Vector2 playerPos = new Vector2(playerController.getPlayer().getPosX(), playerController.getPlayer().getPosY());
        Vector2 direction = playerPos.sub(bossPos).nor();
        Vector2 moveVector = direction.scl(moveSpeed * delta);

        boss.moveBy(moveVector);
    }

    private void dashTowardPlayer() {
        if (boss == null || !boss.isAlive()) return;

        Vector2 bossPos = boss.getPosition().cpy();
        Vector2 playerPos = new Vector2(playerController.getPlayer().getPosX(), playerController.getPlayer().getPosY());
        Vector2 direction = new Vector2(playerPos).sub(bossPos).nor();

        float dashDistance = 250f;
        Vector2 dashTarget = bossPos.cpy().add(direction.scl(dashDistance));

        boss.startDash(dashTarget);
    }

    private void checkBulletCollision(BossEnemy enemy) {
        ArrayList<Bullet> bullets = weaponController.getBullets();
        for (Bullet bullet : bullets) {
            if (bullet.getCollisionRect() != null && enemy.getCollisionRect() != null) {
                if (enemy.getCollisionRect().collidesWith(bullet.getCollisionRect())) {
                    enemy.takeDamage(weaponController.getWeapon().getDamage());
                    weaponController.getBullets().remove(bullet); // ✅ remove bullet after hitting
                    break;
                    // Optionally mark/remove bullet
                }
            }
        }
    }

    private void checkPlayerCollision() {
        if (damageCooldown > 0) return;

        if (boss.getCollisionRect().collidesWith(playerController.getPlayer().getRect())) {
            playerController.getPlayer().reduceHealth(1f);
            playerController.getPlayer().setInvincible(true);
            damageCooldown = damageCooldownTime;
        }
    }

    public boolean isAlive() {
        return boss != null && boss.isAlive();
    }

    private Vector2 worldToScreen(Vector2 world, Player player) {
        float screenX = world.x - player.getPosX() + Gdx.graphics.getWidth() / 2f;
        float screenY = world.y - player.getPosY() + Gdx.graphics.getHeight() / 2f;
        return new Vector2(screenX, screenY);
    }
}
