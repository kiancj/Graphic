package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.controller.ProfileMenuController;

public class ProfileMenuView implements Screen {
    private final Stage stage;
    private final Skin skin;
    private final ProfileMenuController controller;

    private final TextField usernameField;
    private final TextField passwordField;
    private final Label errorLabel;
    private final TextButton changeUsernameButton;
    private final TextButton changeAvatar;
    private final TextButton changePasswordButton;
    private final TextButton deleteAccountButton;

    public ProfileMenuView(ProfileMenuController controller, Skin skin) {
        this.controller = controller;
        this.skin = skin;
        this.stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        usernameField = new TextField("", skin);
        passwordField = new TextField("", skin);
        passwordField.setPasswordMode(true);
        passwordField.setPasswordCharacter('*');

        changeUsernameButton = new TextButton("Change Username", skin);
        changePasswordButton = new TextButton("Change Password", skin);
        deleteAccountButton = new TextButton("Delete Account", skin);
        changeAvatar = new TextButton("Change Avatar", skin);

        errorLabel = new Label("", skin);
        errorLabel.setColor(Color.RED);


    }

    @Override
    public void show() {
        Table table = new Table();
        table.setFillParent(true);
        table.center();
        table.row().pad(10, 0 , 10 , 0);
        table.add(new Label("New Username:", skin));
        table.row().pad(10, 0 , 10 , 0);
        table.add(usernameField).width(200);
        table.row().pad(10, 0 , 10 , 0);
        table.add(changeUsernameButton).height(40);
        table.row().pad(10, 0 , 10 , 0);
        table.add(new Label("New Password:", skin));
        table.row().pad(10, 0 , 10 , 0);
        table.add(passwordField).width(200);
        table.row().pad(10, 0 , 10 , 0);
        table.add(changePasswordButton).height(40);
        table.row().pad(10, 0 , 10 , 0);
        table.add(deleteAccountButton).height(40);
        table.row().pad(10, 0 , 10 , 0);
        table.add(changeAvatar).height(40);
        table.row().pad(10, 0 , 10 , 0);
        table.add(errorLabel);

        stage.addActor(table);
        controller.setView(this);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        stage.act(Math.min(delta, 1 / 30f));
        stage.draw();
        controller.handleProfileMenuActions();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    // Getters
    public TextField getUsernameField() {
        return usernameField;
    }

    public TextField getPasswordField() {
        return passwordField;
    }

    public TextButton getChangeUsernameButton() {
        return changeUsernameButton;
    }

    public TextButton getChangePasswordButton() {
        return changePasswordButton;
    }

    public TextButton getDeleteAccountButton() {
        return deleteAccountButton;
    }

    public TextButton getChangeAvatar() {
        return changeAvatar;
    }

    public void showError(String message) {
        errorLabel.setText(message);
    }
}



