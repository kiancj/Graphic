package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.SettingMenuController;
import io.github.some_example_name.controller.SignUpMenuController;
import io.github.some_example_name.model.App;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SettingMenuView implements Screen {
    private Stage stage;
    public Table table;
    private final TextField volumeField;
    private final TextField musicNumber;
    private final Label autoReload;
    private final SelectBox auto;
    private final SelectBox sfx;
    private final Label sfxTitle;
    private final Label menuName;
    private final SettingMenuController controller;
    private final TextButton confirm;

    public SettingMenuView(SettingMenuController controller, Skin skin) {
        this.controller = controller;
        this.table = new Table();
        sfx = new SelectBox<>(skin);
        auto = new SelectBox<>(skin);
        autoReload = new Label("AUTO RELOAD",skin);
        sfxTitle = new Label("SFX",skin);
        this.musicNumber = new TextField("Enter the number between 1 and 2 to choose the music.",skin);
        this.menuName = new Label("Settings",skin);
        this.volumeField = new TextField("Enter a value 0 and 100 to set the volume.",skin);
        this.confirm = new TextButton("Confirm",skin);
        controller.setView(this);
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        Array<String> options = new Array<>();
        options.add("ON");
        options.add("OFF");
        sfx.setItems(options);
        auto.setItems(options);
        table.setFillParent(true);
        table.center();
        table.add(menuName);// Add a label for clarity
        table.row().pad(10, 0, 10, 0);
        table.add(volumeField).width(600);
        table.row().pad(10, 0, 10, 0);
        table.add(musicNumber).width(600);
        table.row().pad(10, 0, 10, 0);
        table.add(autoReload);
        table.row().pad(10, 0, 10, 0);
        table.add(auto);
        table.row().pad(10, 0, 10, 0);
        table.add(sfxTitle);
        table.row().pad(10, 0, 10, 0);
        table.add(sfx);
        table.row().pad(10, 0, 10, 0);
        table.add(confirm);

        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        String SFX = sfx.getSelected().toString();
        String AUTO = auto.getSelected().toString();
        controller.handleSettingButtons(SFX , AUTO);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public TextButton getConfirm() {
        return confirm;
    }

    public TextField getVolumeField() {
        return volumeField;
    }

    public TextField getMusicNumber() {
        return musicNumber;
    }


}
