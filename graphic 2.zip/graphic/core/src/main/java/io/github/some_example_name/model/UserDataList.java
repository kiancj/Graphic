package io.github.some_example_name.model;



import java.util.ArrayList;
import java.util.List;

public class UserDataList {
    public List<UserData> users = new ArrayList<>();
}
