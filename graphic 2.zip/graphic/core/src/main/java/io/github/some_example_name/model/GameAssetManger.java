package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

public class GameAssetManger {
    private static GameAssetManger gameAssetManager;
    private final String elder = "elder.png";
    private final String yuz = "avatar/yuz.jpeg";
    private final String diddy = "avatar/diddy.jpeg";
    private final String golzar = "avatar/golzar.jpeg";
    private final Skin skin = new Skin(Gdx.files.internal("skin/pixthulhu-ui.json"));
    private Music backgroundMusic1 = Gdx.audio.newMusic(Gdx.files.internal("music/01. Pretty Dungeon.mp3"));
    private Music backgroundMusic2 = Gdx.audio.newMusic(Gdx.files.internal("music/02. Wasteland Combat.mp3"));
    // hero1
    private final String character1_run0 = "1/Run_0.png";
    private final String character1_run1 = "1/Run_1.png";
    private final String character1_run2 = "1/Run_2.png";
    private final String character1_run3 = "1/Run_3.png";
    private final Texture character1_run0_tex = new Texture(character1_run0);
    private final Texture character1_run1_tex = new Texture(character1_run1);
    private final Texture character1_run2_tex = new Texture(character1_run2);
    private final Texture character1_run3_tex = new Texture(character1_run3);
    private final Animation<Texture> character1_run_frames = new Animation<>(0.1f, character1_run0_tex, character1_run1_tex, character1_run2_tex, character1_run3_tex);
    // hero2
    private final String character2_run0 = "2/Run_0.png";
    private final String character2_run1 = "2/Run_1.png";
    private final String character2_run2 = "2/Run_2.png";
    private final String character2_run3 = "2/Run_3.png";
    private final Texture character2_run0_tex = new Texture(character2_run0);
    private final Texture character2_run1_tex = new Texture(character2_run1);
    private final Texture character2_run2_tex = new Texture(character2_run2);
    private final Texture character2_run3_tex = new Texture(character2_run3);
    private final Animation<Texture> character2_run_frames = new Animation<>(0.1f, character2_run0_tex, character2_run1_tex, character2_run2_tex, character2_run3_tex);
    // hero 3
    private final String character3_run0 = "3/Run_0.png";
    private final String character3_run1 = "3/Run_1.png";
    private final String character3_run2 = "3/Run_2.png";
    private final String character3_run3 = "3/Run_3.png";
    private final Texture character3_run0_tex = new Texture(character3_run0);
    private final Texture character3_run1_tex = new Texture(character3_run1);
    private final Texture character3_run2_tex = new Texture(character3_run2);
    private final Texture character3_run3_tex = new Texture(character3_run3);
    private final Animation<Texture> character3_run_frames = new Animation<>(0.1f, character3_run0_tex, character3_run1_tex, character3_run2_tex, character3_run3_tex);
    // hero 4
    private final String character4_run0 = "4/Run_0.png";
    private final String character4_run1 = "4/Run_1.png";
    private final String character4_run2 = "4/Run_2.png";
    private final String character4_run3 = "4/Run_3.png";
    private final Texture character4_run0_tex = new Texture(character4_run0);
    private final Texture character4_run1_tex = new Texture(character4_run1);
    private final Texture character4_run2_tex = new Texture(character4_run2);
    private final Texture character4_run3_tex = new Texture(character4_run3);
    private final Animation<Texture> character4_run_frames = new Animation<>(0.1f, character4_run0_tex, character4_run1_tex, character4_run2_tex, character4_run3_tex);
    // hero 5
    private final String character5_run0 = "5/Run_0.png";
    private final String character5_run1 = "5/Run_1.png";
    private final String character5_run2 = "5/Run_2.png";
    private final String character5_run3 = "5/Run_3.png";
    private final Texture character5_run0_tex = new Texture(character5_run0);
    private final Texture character5_run1_tex = new Texture(character5_run1);
    private final Texture character5_run2_tex = new Texture(character5_run2);
    private final Texture character5_run3_tex = new Texture(character5_run3);
    private final Animation<Texture> character5_run_frames = new Animation<>(0.1f, character5_run0_tex, character5_run1_tex, character5_run2_tex, character5_run3_tex);
    // death
    private final String death_0 = "death/DeathFX_0.png";
    private final String death_1 = "death/DeathFX_1.png";
    private final String death_2 = "death/DeathFX_2.png";
    private final String death_3 = "death/DeathFX_3.png";
    private final Texture death0Tex = new Texture(death_0);
    private final Texture death1Tex = new Texture(death_1);
    private final Texture death2Tex = new Texture(death_2);
    private final Texture death3Tex = new Texture(death_3);
    private final Animation<Texture> death_frame = new Animation<>(0.2f, death0Tex, death1Tex, death2Tex, death3Tex);
    //enemy1
    private final String enemy0 = "TentacleIdle/TentacleIdle0.png";
    private final String enemy1 = "TentacleIdle/TentacleIdle1.png";
    private final String enemy2 = "TentacleIdle/TentacleIdle2.png";
    private final String enemy3 = "TentacleIdle/TentacleIdle3.png";
    private final Texture enemy0Tex = new Texture(enemy0);
    private final Texture enemy1Tex = new Texture(enemy1);
    private final Texture enemy2Tex = new Texture(enemy2);
    private final Texture enemy3Tex = new Texture(enemy3);
    private final Animation<Texture> enemy = new Animation<>(0.1f, enemy0Tex, enemy1Tex, enemy2Tex, enemy3Tex);
    //boss
    private final String boss0 = "Boss/T_ShubNiggurath_0.png";
    private final String boss1 = "Boss/T_ShubNiggurath_1.png";
    private final String boss2 = "Boss/T_ShubNiggurath_2.png";
    private final String boss3 = "Boss/T_ShubNiggurath_3.png";
    private final String boss4 = "Boss/T_ShubNiggurath_4.png";
    private final String boss5 = "Boss/T_ShubNiggurath_5.png";
    private final String boss6 = "Boss/T_ShubNiggurath_6.png";
    private final String boss7 = "Boss/T_ShubNiggurath_7.png";
    private final String boss8 = "Boss/T_ShubNiggurath_8.png";
    private final String boss9 = "Boss/T_ShubNiggurath_9.png";
    private final String boss10 = "Boss/T_ShubNiggurath_10.png";
    private final Texture boss0Tex = new Texture(boss0);
    private final Texture boss1Tex = new Texture(boss1);
    private final Texture boss2Tex = new Texture(boss2);
    private final Texture boss3Tex = new Texture(boss3);
    private final Texture boss4Tex = new Texture(boss4);
    private final Texture boss5Tex = new Texture(boss5);
    private final Texture boss6Tex = new Texture(boss6);
    private final Texture boss7Tex = new Texture(boss7);
    private final Texture boss8Tex = new Texture(boss8);
    private final Texture boss9Tex = new Texture(boss9);
    private final Texture boss10Tex = new Texture(boss10);
    private final Animation<Texture> boss = new Animation<>(0.3f, boss4Tex, boss5Tex, boss6Tex, boss7Tex, boss8Tex, boss9Tex, boss10Tex);

    //
    private final String cursor = "T_Cursor.png";
    private final String smg = "smg/SMG.png";
    private final Texture smgTexture = new Texture(smg);

    private final String shotgun = "shotgun/Shotgun.png";
    private final Texture shotgunTexture = new Texture(shotgun);

    private final String revolver = "revolver/RevolverStill.png";
    private final Texture revolverTexture = new Texture(revolver);

    private final String bullet = "bullet.png";
    private final String XpDot = "bullet.png";

    private final Texture lightTexture = new Texture("light.png");
    Sprite lightSprite = new Sprite(lightTexture);
    private final Sound enemyKilled = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Blood_Splash_Quick_01.wav"));

    private final Sound playerKilled = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Explosion_Blood_01.wav"));

    private final Sound coins = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Coins (10).wav"));

    private final Sound levelUp = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Special & Powerup (8).wav"));

    private final Sound walk1 = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Footsteps_Casual_Grass_01.wav"));

    private final Sound walk2 = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Footsteps_Casual_Grass_02.wav"));

    private final Sound walk3 = Gdx.audio.newSound(Gdx.files.internal("AudioClip/Footsteps_Casual_Grass_03.wav"));

    private final Sound shoot = Gdx.audio.newSound(Gdx.files.internal("AudioClip/single_shot.wav"));

    private GameAssetManger() {

    }

    public static GameAssetManger getGameAssetManager() {
        if (gameAssetManager == null) {
            gameAssetManager = new GameAssetManger();
        }
        return gameAssetManager;
    }

    public Skin getSkin() {
        return skin;
    }

    public Animation<Texture> getCharacter1_idle_animation() {
        return character1_run_frames;
    }

    public Animation<Texture> getCharacter2_run_frames() {
        return character2_run_frames;
    }

    public Animation<Texture> getCharacter3_run_frames() {
        return character3_run_frames;
    }

    public Animation<Texture> getCharacter4_run_frames() {
        return character4_run_frames;
    }

    public Animation<Texture> getCharacter5_run_frames() {
        return character5_run_frames;
    }

    public String getCharacter1_idle0() {
        return character1_run0;
    }

    public Texture getSmgTexture() {
        return smgTexture;
    }

    public String getSmg() {
        return smg;
    }

    public String getBullet() {
        return bullet;
    }

    public Music getBackgroundMusic1() {
        return backgroundMusic1;
    }

    public Music getBackgroundMusic2() {
        return backgroundMusic2;
    }

    public String getXpDot() {
        return XpDot;
    }

    public String getTreeTexture() {
        return "tree.png"; // or wherever your tree asset is
    }

    public String getElder() {
        return elder;
    }

    public Texture getShotgunTexture() {
        return shotgunTexture;
    }

    public Texture getRevolverTexture() {
        return revolverTexture;
    }

    public String getYuz() {
        return yuz;
    }

    public String getDiddy() {
        return diddy;
    }

    public String getGolzar() {
        return golzar;
    }

    public Animation<Texture> getDeath_frame() {
        return death_frame;
    }

    public String getCursor() {
        return cursor;
    }

    public Sprite getLightSprite() {
        return lightSprite;
    }

    public Sound getShoot() {
        return shoot;
    }

    public Sound getWalk3() {
        return walk3;
    }

    public Sound getWalk2() {
        return walk2;
    }

    public Sound getWalk1() {
        return walk1;
    }

    public Sound getLevelUp() {
        return levelUp;
    }

    public Sound getCoins() {
        return coins;
    }

    public Sound getPlayerKilled() {
        return playerKilled;
    }

    public Sound getEnemyKilled() {
        return enemyKilled;
    }

    public Animation<Texture> getBoss() {
        return new Animation<Texture>(0.1f, boss0Tex, boss1Tex, boss2Tex, boss3Tex);
    }

    public Animation<Texture> getBossAnimation() {
        return boss;
    }

    public String getboss() {
        return boss0;
    }
}
