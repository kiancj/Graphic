package io.github.some_example_name.controller;

import io.github.some_example_name.model.Player;
import io.github.some_example_name.model.Tree;

import java.util.ArrayList;
import java.util.Iterator;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.MathUtils;

public class TreeController {
    private ArrayList<Tree> trees = new ArrayList<>();
    private PlayerController playerController;
    private float treeDamageCooldown = 1.0f; // seconds between damage
    private float timeSinceLastDamage = 0f;

    public TreeController(PlayerController playerController) {
        this.playerController = playerController;
        generateTrees(5); // Spawn 20 random trees at start
    }

    public void update(float delta) {
        Player player = playerController.getPlayer();
        timeSinceLastDamage += delta;

        for (Tree tree : trees) {
            tree.updateCollisionRect();
            if (tree.getCollisionRect().collidesWith(player.getRect())) {
                if (timeSinceLastDamage >= treeDamageCooldown) {
                    player.reduceHealth(1f);
                    timeSinceLastDamage = 0f;
                }
            }
            tree.draw(player.getPosX(), player.getPosY());
        }
    }

    private void generateTrees(int count) {
        for (int i = 0; i < count; i++) {
            float worldX = MathUtils.random(0, 1000); // Random world coords
            float worldY = MathUtils.random(0, 800);
            trees.add(new Tree(worldX, worldY));
        }
    }

    public ArrayList<Tree> getTrees() {
        return trees;
    }
}
