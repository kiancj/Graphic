package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.LoginMenuController;
import io.github.some_example_name.controller.MainMenuController;

public class LoginMenuView implements Screen {
    private Stage stage;
    private final TextButton playButton;
    private final TextButton playButton1;
    private final TextButton playButton2;
    private final Label gameTitle;
    private final Label label;
    private final TextField field;
    private final TextField field1;
    public Table table;
    private final LoginMenuController controller;
    private final Texture background;

    public LoginMenuView(LoginMenuController controller, Skin skin) {
        this.controller = controller;
        this.playButton = new TextButton("Login", skin);
        this.gameTitle = new Label("Login Menu", skin);
        this.field = new TextField("Enter username", skin);
        this.field1 = new TextField("Enter password.",skin);
        this.table = new Table();
        this.label = new Label("",skin);
        this.playButton1 = new TextButton("Forget Pass", skin);
        this.playButton2 = new TextButton("Sign Up", skin);
        controller.setView(this , skin);
        background = new Texture("wallpaper.png");
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        table.setFillParent(true);
        table.center();
        table.row().pad(5, 0 , 5 , 0);
        table.add(label).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(gameTitle).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(field).width(600);
        table.row().pad(10, 0 , 5 , 0);
        table.add(field1).width(600);
        table.row();
        table.add(playButton).size(500, 40).pad(10);
        table.row();
        table.add(playButton1).size(500, 40).pad(10);
        table.row();
        table.add(playButton2).size(500, 40).pad(10);
        stage.addActor(table);
        label.setColor(Color.RED);
        gameTitle.setColor(Color.RED);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        controller.handleMainMenuButtons();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public TextButton getPlayButton() {
        return playButton;
    }

    public TextButton getPlayButton1() {
        return playButton1;
    }

    public TextButton getPlayButton2() {
        return playButton2;
    }

    public TextField getField() {
        return field;
    }
    public TextField getField1() {
        return field1;
    }

    public Label getLabel() {
        return label;
    }
}
