package io.github.some_example_name.controller;

import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.view.*;

public class MainMenuController {
    private MainMenuView view;

    public void setView(MainMenuView view) {
        this.view = view;
    }

    public void handleMainMenuButtons(String selected) {
        if (view != null) {
            if(view.getLogoutButton().isPressed()){
                Main.getMain().getScreen().dispose();
                App.setCurrentUser(null);
                Main.getMain().setScreen(new LoginMenuView(new LoginMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(selected.equals("HINT_MENU")){
                Main.getMain().setScreen(new HintMenuView(new HintMenuController(),GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(selected.equals("Settings")){
                Main.getMain().setScreen(new SettingMenuView(new SettingMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(selected.equals("Profile")){
                Main.getMain().setScreen(new ProfileMenuView(new ProfileMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(selected.equals("Pre_Game")){
                Main.getMain().setScreen(new PreGameMenuView(new PreGameMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(selected.equals("Score_Board")){
                Main.getMain().setScreen(new ScoreBoardView(new ScoreBoardController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(selected.equals("Continue Saved Game")){
                /// todo go to saved game
            }

        }
    }

}
