package io.github.some_example_name.model;

public class UserData {
    public String username;
    public String password;
    public String schoolName;
    public int score;
    public int kills;
    public int mostTimeStayedAlive;

    public UserData() {} // Needed for Gson

    public UserData(User user) {
        this.username = user.getUsername();
        this.password = user.getPassword();
        this.schoolName = user.getSchoolName();
        this.score = user.getScore();
        this.kills = user.getKills();
        this.mostTimeStayedAlive = user.getMostTimeStayedAlive();
    }
}

