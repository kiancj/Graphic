package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.MainMenuController;
import io.github.some_example_name.model.App;

public class MainMenuView implements Screen {
    private Music backgroundMusic;
    private Stage stage;
    private final TextButton LogoutButton;
    private final Label gameTitle;
    private final TextField field;
    public Table table;
    private final Skin skin;
    private final MainMenuController controller;
    private SelectBox<String> selectBox;
    private Texture character1_idle0_tex;
    private  final Label name;
    private final Label score;
    public MainMenuView(MainMenuController controller, Skin skin) {
        this.controller = controller;
        String Score = String.valueOf(App.getCurrentUser().getScore());
        this.LogoutButton = new TextButton("Logout", skin);
        LogoutButton.setColor(Color.RED);
        this.gameTitle = new Label("20 Minutes Till Dawn", skin);
        this.name = new Label("Username : "+App.getCurrentUser().getUsername(), skin);
        this.score = new Label("Score : "+Score, skin);
        this.field = new TextField("this is a field", skin);
        this.table = new Table();
        this.skin = skin;
        controller.setView(this);
    }


    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
// 3. Create and set the items
        character1_idle0_tex = new Texture(App.getCurrentUser().getAvatarAddress());
        Image avatar = new Image(character1_idle0_tex);
// Optional: Set position or size
        avatar.setSize(100, 100);
        avatar.setPosition(200, 200);
        selectBox = new SelectBox<>(skin);
        Array<String> items = new Array<String>();
        items.add("NONE");
        items.add("HINT_MENU");
        items.add("Settings");
        items.add("Profile");
        items.add("Pre_Game");
        items.add("Score_Board");
        items.add("Continue Saved Game");
        selectBox.setItems(items);
// 5. Add to stage
        table = new Table();
        table.setFillParent(true);
        table.center();
        table.row().pad(10, 0 , 10 , 0);
        table.add(gameTitle);
        table.row().pad(10, 0 , 10 , 0);
        table.add(avatar).width(100).height(100);
        table.row().pad(10, 0 , 10 , 0);
        table.add(name);
        table.row().pad(10, 0 , 10 , 0);
        table.add(score);
        table.add(selectBox).width(200).pad(10);
        table.row().pad(10, 0 , 10 , 0);
        table.add(LogoutButton);
        stage.addActor(table);

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        String selected = selectBox.getSelected();
        controller.handleMainMenuButtons(selected);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

        stage.dispose();

    }

    public TextButton getLogoutButton() {
        return LogoutButton;
    }

    public TextField getField() {
        return field;
    }
}
