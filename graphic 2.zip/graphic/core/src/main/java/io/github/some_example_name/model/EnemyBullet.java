package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.Main;

public class EnemyBullet {

    private Texture texture = new Texture(GameAssetManger.getGameAssetManager().getBullet());
    private Sprite sprite = new Sprite(texture);

    private float worldX;
    private float worldY;
    private final float speed = 200f;

    private float directionX;
    private float directionY;

    private CollisionRect collisionRect;

    public EnemyBullet(float startX, float startY, float targetX, float targetY) {
        this.worldX = startX;
        this.worldY = startY;

        // Compute normalized direction
        float dx = targetX - startX;
        float dy = targetY - startY;
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        if (length != 0) {
            directionX = dx / length;
            directionY = dy / length;
        } else {
            directionX = 0;
            directionY = 0;
        }

        sprite.setSize(20, 20);
        sprite.setOriginCenter();

        collisionRect = new CollisionRect(worldX, worldY, sprite.getWidth(), sprite.getHeight());
    }

    public void update(float delta) {
        worldX += directionX * speed * delta;
        worldY += directionY * speed * delta;

        if (collisionRect != null) {
            collisionRect.move(worldX, worldY);
        }
    }

    public void draw(float playerWorldX, float playerWorldY) {
        float screenX = worldX - playerWorldX + Gdx.graphics.getWidth() / 2f;
        float screenY = worldY - playerWorldY + Gdx.graphics.getHeight() / 2f;

        sprite.setPosition(screenX, screenY);
        sprite.draw(Main.getBatch());
    }

    public boolean isOffScreen(float playerWorldX, float playerWorldY) {
        float screenX = worldX - playerWorldX + Gdx.graphics.getWidth() / 2f;
        float screenY = worldY - playerWorldY + Gdx.graphics.getHeight() / 2f;

        return screenX < -20 || screenX > Gdx.graphics.getWidth() + 20 ||
            screenY < -20 || screenY > Gdx.graphics.getHeight() + 20;
    }

    public CollisionRect getCollisionRect() {
        return collisionRect;
    }
}
