package io.github.some_example_name.controller;

import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.User;
import io.github.some_example_name.view.*;

public class EndMenuController {
    private EndMenuView view;
    private Skin skin;

    public void setView(EndMenuView view , Skin skin) {
        this.view = view;
        this.skin = skin;
    }

    public void handleMainMenuButtons() {

        if(view.getPlayButton().isPressed()){
            Main.getMain().getScreen().dispose();
            Main.getMain().setScreen(new MainMenuView(new MainMenuController(),GameAssetManger.getGameAssetManager().getSkin()));
        }
    }
}
