package io.github.some_example_name.controller;



import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;

import java.util.ArrayList;
import java.util.Iterator;

public class EnemyController {
    private ArrayList<Enemy> enemies = new ArrayList<>();
    private PlayerController playerController;
    private WeaponController weaponController;
    private float spawnTimer = 0f;
    private float spawnRate = 3f; // seconds
    private float elapsedTime = 0f;
    private ArrayList<XpDot> xpDots = new ArrayList<>();


    public EnemyController(PlayerController playerController, WeaponController weaponController) {
        this.playerController = playerController;
        this.weaponController = weaponController;
    }

    public void update(float delta) {
        spawnTimer += delta;
        elapsedTime += delta;

        if (spawnTimer >= spawnRate) {
            spawnTimer = 0;

            // Calculate number of enemies to spawn based on elapsed time
            int enemiesToSpawn = Math.max(1, (int)(elapsedTime / 30f));
            for (int i = 0; i < enemiesToSpawn; i++) {
                spawnEnemy();
            }

            // Optional: Remove or adjust spawnRate logic if needed
        }


        Iterator<Enemy> iterator = enemies.iterator();
        while (iterator.hasNext()) {
            Enemy enemy = iterator.next();
            if (!enemy.isAlive()) {
                if (!enemy.isDying()) {
                    float worldX = enemy.getSprite().getX() - Gdx.graphics.getWidth() / 2f + playerController.getPlayer().getPosX();
                    float worldY = enemy.getSprite().getY() - Gdx.graphics.getHeight() / 2f + playerController.getPlayer().getPosY();
                    xpDots.add(new XpDot(worldX, worldY));
                    App.getCurrentUser().increaseKill(1);
                    playerController.getPlayer().increaseKill(1);
                    if(App.getCurrentUser().isSfxActive()){
                        GameAssetManger.getGameAssetManager().getEnemyKilled().play();
                    }
                    enemy.die(); // Start the animation
                } else {
                    enemy.updateDeathAnimation(delta);
                    Main.getBatch().draw(enemy.getCurrentDeathFrame(), enemy.getSprite().getX(), enemy.getSprite().getY());

                    if (enemy.shouldBeRemoved()) {
                        iterator.remove();
                    }
                }
                continue;
            }


            moveEnemyTowardsPlayer(enemy);
            checkBulletCollision(enemy);
            enemy.update(delta);
            Main.getBatch().draw(
                enemy.getCurrentFrame(),
                enemy.getSprite().getX(),
                enemy.getSprite().getY(),
                enemy.getSprite().getWidth(),
                enemy.getSprite().getHeight()
            );

            if (playerController.getPlayer().getRect() != null && enemy.getCollisionRect() != null) {
                if (enemy.getCollisionRect().collidesWith(playerController.getPlayer().getRect()) && !playerController.getPlayer().isInvincible()) {
                    playerController.getPlayer().reduceHealth(1f);
                    enemy.setAlive(false);
                    if(App.getCurrentUser().isSfxActive()){
                        GameAssetManger.getGameAssetManager().getEnemyKilled().play();
                    }
                    playerController.getPlayer().setInvincible(true);
                    continue;
                }
            }
            enemy.updateCollisionRect(playerController.getPlayer());

        }
        Iterator<XpDot> xpIterator = xpDots.iterator();
        while (xpIterator.hasNext()) {
            XpDot dot = xpIterator.next();

            // Check if player collides with it
            dot.updateCollisionRect();
            if (dot.getCollisionRect().collidesWith(playerController.getPlayer().getRect())) {
                if(App.getCurrentUser().isSfxActive()){
                    GameAssetManger.getGameAssetManager().getCoins().play();
                }
                dot.collect();
                playerController.getPlayer().addXp(3);// You need to implement this
                xpIterator.remove(); // remove after collected
            } else {
                dot.draw(Main.getBatch(), playerController.getPlayer().getPosX(), playerController.getPlayer().getPosY());
            }
        }

    }

    private void spawnEnemy() {
        float x = 0, y = 0;
        int edge = MathUtils.random(3); // 0=top, 1=bottom, 2=left, 3=right
        switch (edge) {
            case 0: // Top
                x = MathUtils.random(Gdx.graphics.getWidth());
                y = Gdx.graphics.getHeight();
                break;
            case 1: // Bottom
                x = MathUtils.random(Gdx.graphics.getWidth());
                y = 0;
                break;
            case 2: // Left
                x = 0;
                y = MathUtils.random(Gdx.graphics.getHeight());
                break;
            case 3: // Right
                x = Gdx.graphics.getWidth();
                y = MathUtils.random(Gdx.graphics.getHeight());
                break;
        }

        enemies.add(new Enemy(x, y));
    }

    private void moveEnemyTowardsPlayer(Enemy enemy) {
        Sprite sprite = enemy.getSprite();
        Vector2 direction = new Vector2(
            Gdx.graphics.getWidth() / 2f - sprite.getX(),
            Gdx.graphics.getHeight() / 2f - sprite.getY()
        ).nor();

        sprite.setX(sprite.getX() + direction.x * 0.2f); // Speed can be adjusted
        sprite.setY(sprite.getY() + direction.y * 0.2f);
    }

    private void checkBulletCollision(Enemy enemy) {
        ArrayList<Bullet> bullets = weaponController.getBullets();
        for (Bullet bullet : bullets) {
            if (bullet.getCollisionRect() != null && enemy.getCollisionRect() != null) {
            if (enemy.getCollisionRect().collidesWith(bullet.getCollisionRect())) {
                enemy.takeDamage(weaponController.getWeapon().getDamage());
                weaponController.getBullets().remove(bullet); // ✅ remove bullet after hitting
                break;
                // Optionally mark/remove bullet
              }
            }
        }
    }


    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }
}


