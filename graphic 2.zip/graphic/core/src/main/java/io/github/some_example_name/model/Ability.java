package io.github.some_example_name.model;



public class Ability {
    private final AbilityType type;
    private float duration; // Only used for temporary abilities
    private boolean active;
    private boolean applied;

    public Ability(AbilityType type, float duration) {
        this.type = type;
        this.duration = duration;
        this.active = true;
        this.applied = false;
    }

    public AbilityType getType() {
        return type;
    }

    public float getDuration() {
        return duration;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isApplied() {
        return applied;
    }

    /**
     * Apply the effect once (e.g., buff the player)
     */
    public void applyEffect(Player player) {
        if (applied) return;

        switch (type) {
            case VITALITY:
                 // example
                break;
            case DAMAGER:
                 // temporary, multiplier
                break;
            case PROCREASE:

                break;
            case AMOCREASE:

                break;
            case SPEEDY:
                player.increaseSpeed();
                break;
        }

        applied = true;
    }

    /**
     * Reverse the effect (only for temporary abilities)
     */
    public void removeEffect(Player player) {
        if (!applied) return;

        switch (type) {
            case DAMAGER:
               // player.resetDamage();
                break;
            case SPEEDY:
                //player.resetSpeed();
                break;
            // Permanent effects don’t get removed
            default:
                break;
        }

        active = false;
    }

    /**
     * Called every frame if active; updates timer & disables when done
     */
    public void update(float delta, Player player) {
        if (!active || !applied) return;

        if (duration > 0) {
            duration -= delta;
            if (duration <= 0) {
                removeEffect(player);
            }
        }
    }

}

