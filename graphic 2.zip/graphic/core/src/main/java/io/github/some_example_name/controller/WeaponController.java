package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.Bullet;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.Weapon;


import java.util.ArrayList;
import java.util.Iterator;

public class WeaponController {
    private Weapon weapon;
    private ArrayList<Bullet> bullets = new ArrayList<>();

    public WeaponController(Weapon weapon){
        this.weapon = weapon;
        App.getCurrentPlayer().setWeapon(weapon);
    }

    public void update(){
        if (weapon.isReloading()) {
            weapon.setReloadTimer(weapon.getReloadTimer() + Gdx.graphics.getDeltaTime());
            if (weapon.getReloadTimer() >= weapon.getReloadTime()) {
                weapon.setAmmo(weapon.getMaxAmmo());
                weapon.setReloading(false);
                weapon.setReloadTimer(0f);
            }
            return;
        }

        weapon.getSmgSprite().draw(Main.getBatch());
        updateBullets();
    }

    public void handleWeaponRotation(int x, int y) {
        Sprite weaponSprite = weapon.getSmgSprite();

        float weaponCenterX = (float) Gdx.graphics.getWidth() / 2;
        float weaponCenterY = (float) Gdx.graphics.getHeight() / 2;

        float angle = (float) Math.atan2(y - weaponCenterY, x - weaponCenterX);

        weaponSprite.setRotation((float) (3.14 - angle * MathUtils.radiansToDegrees));
    }

    public void handleWeaponShoot(int x, int y) {
        if (weapon.isReloading()) return;

        if (weapon.getAmmo() > 0) {
            if (weapon.isShotgun()) {
                int pellets = 4;
                float spreadAngle = 20f;

                float centerX = Gdx.graphics.getWidth() / 2f;
                float centerY = Gdx.graphics.getHeight() / 2f;
                float baseAngle = (float) Math.atan2(y - centerY, x - centerX);

                for (int i = 0; i < pellets+ weapon.getProcrease(); i++) {
                    float offset = MathUtils.random(-spreadAngle / 2f, spreadAngle / 2f);
                    float finalAngle = baseAngle + offset * MathUtils.degreesToRadians;

                    float targetX = (float) (centerX + Math.cos(finalAngle) * 1000);
                    float targetY = (float) (centerY + Math.sin(finalAngle) * 1000);
                    GameAssetManger.getGameAssetManager().getShoot().play();
                    bullets.add(new Bullet((int) targetX, (int) targetY));
                }
            } else {
                if(weapon.getProcrease() == 1){
                    bullets.add(new Bullet(x, y));
                }
                else{
                    float spreadAngle = 20f;

                    float centerX = Gdx.graphics.getWidth() / 2f;
                    float centerY = Gdx.graphics.getHeight() / 2f;
                    float baseAngle = (float) Math.atan2(y - centerY, x - centerX);

                    for (int i = 0; i < weapon.getProcrease(); i++) {
                        float offset = MathUtils.random(-spreadAngle / 2f, spreadAngle / 2f);
                        float finalAngle = baseAngle + offset * MathUtils.degreesToRadians;

                        float targetX = (float) (centerX + Math.cos(finalAngle) * 1000);
                        float targetY = (float) (centerY + Math.sin(finalAngle) * 1000);
                        bullets.add(new Bullet((int) targetX, (int) targetY));
                    }
                }

            }
            if(App.getCurrentUser().isSfxActive()){
                GameAssetManger.getGameAssetManager().getShoot().play();
            }
            weapon.setAmmo(weapon.getAmmo() - 1);
        }
        else if(App.getCurrentUser().isAutoReload()){
            weapon.setReloading(true);
            weapon.setReloadTimer(0f);
        }
    }


    //    public void updateBullets() {
//        for(Bullet b : bullets) {
//            b.getSprite().draw(Main.getBatch());
//            Vector2 direction = new Vector2(
//                Gdx.graphics.getWidth()/2f - b.getX(),
//                Gdx.graphics.getHeight()/2f - b.getY()
//            ).nor();
//
//            b.getSprite().setX(b.getSprite().getX() - direction.x * 5);
//            b.getSprite().setY(b.getSprite().getY() + direction.y * 5);
//        }
//    }
public void updateBullets() {
    Iterator<Bullet> iterator = bullets.iterator();
    while (iterator.hasNext()) {
        Bullet b = iterator.next();
        b.updatePosition(App.getCurrentPlayer().getPosX(),App.getCurrentPlayer().getPosY());

        if (b.isOffScreen()) {
            iterator.remove();
            continue;
        }

        b.getSprite().draw(Main.getBatch());
    }
}


    public Weapon getWeapon() {
        return weapon;
    }

    public ArrayList<Bullet> getBullets() {
        return bullets;
    }
}
