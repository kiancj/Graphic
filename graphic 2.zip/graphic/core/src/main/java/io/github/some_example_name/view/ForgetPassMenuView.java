package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.ForgetPassController;

public class ForgetPassMenuView implements Screen {
    private Stage stage;
    private final TextButton playButton;
    private final Label label;
    private final TextField field;
    private final TextField field1;
    private final TextField field2;
    public Table table;
    private final ForgetPassController controller;

    public ForgetPassMenuView(ForgetPassController controller, Skin skin) {
        this.controller = controller;
        this.playButton = new TextButton("click", skin);
        this.field = new TextField("Enter username", skin);
        this.field1 = new TextField("Enter school name",skin);
        this.field2 = new TextField("Enter new password" , skin);
        this.table = new Table();
        this.label = new Label("",skin);
        controller.setView(this);
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        table.setFillParent(true);
        table.center();
        table.row().pad(5, 0 , 5 , 0);
        table.add(label).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(field).width(600);
        table.row().pad(10, 0 , 5 , 0);
        table.add(field1).width(600);
        table.row().pad(10, 0 , 5 , 0);
        table.add(field2).width(600);
        table.row();
        table.add(playButton).size(500, 40).pad(10);
        stage.addActor(table);
        label.setColor(Color.RED);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        controller.handleForgetPassButton();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public TextButton getPlayButton() {
        return playButton;
    }


    public TextField getField() {
        return field;
    }
    public TextField getField1() {
        return field1;
    }
    public TextField getField2() {
        return field2;
    }

    public Label getLabel() {
        return label;
    }
}
