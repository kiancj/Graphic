package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.EventListener;
import io.github.some_example_name.view.PauseMenuView;

public class PauseMenuController {

    private boolean paused = false;
    private final PauseMenuView pauseMenuView;
    private final Runnable onResume;
    private final Runnable onMainMenu;
    private final Runnable onExit;
    private final InputProcessor gameInputProcessor; // 👈 Add this

    public PauseMenuController(
        PauseMenuView view,
        Runnable onResume,
        Runnable onMainMenu,
        Runnable onExit,
        InputProcessor gameInputProcessor // 👈 Pass your game view or stage here
    ) {
        this.pauseMenuView = view;
        this.onResume = onResume;
        this.onMainMenu = onMainMenu;
        this.onExit = onExit;
        this.gameInputProcessor = gameInputProcessor;

        addListeners();
    }

    private void addListeners() {
        pauseMenuView.getResumeButton().addListener(eventListener(() -> {
            onResume.run();
            setPaused(false); // ✅ Clear and restore input
        }));
        pauseMenuView.getMainMenuButton().addListener(eventListener(onMainMenu));
        pauseMenuView.getExitButton().addListener(eventListener(onExit));
    }

    private EventListener eventListener(final Runnable action) {
        return new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                action.run();
            }
        };
    }

    public void togglePause() {
        setPaused(!paused);
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
        if (paused) {
            Gdx.input.setInputProcessor(pauseMenuView.getStage());
        } else {
            Gdx.input.setInputProcessor(gameInputProcessor); // ✅ restore game input
        }
    }

    public boolean isPaused() {
        return paused;
    }

    public void update() {
        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            togglePause();
        }
    }

    public PauseMenuView getView() {
        return pauseMenuView;
    }
}
