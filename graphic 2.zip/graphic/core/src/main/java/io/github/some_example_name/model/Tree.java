package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import io.github.some_example_name.Main;

public class Tree {
    private Sprite sprite;
    private CollisionRect collisionRect;
    private float worldX, worldY;


    public Tree(float worldX, float worldY) {
        Texture texture = new Texture(GameAssetManger.getGameAssetManager().getTreeTexture()); // Make sure asset exists
        this.sprite = new Sprite(texture);
        this.sprite.setSize(64, 64); // Adjust size as needed
        this.worldX = worldX;
        this.worldY = worldY;
        this.sprite.setPosition(worldX, worldY);
        this.collisionRect = new CollisionRect(worldX, worldY, sprite.getWidth(), sprite.getHeight());
    }

    public void draw(float playerWorldX, float playerWorldY) {
        float screenX = worldX - playerWorldX + Gdx.graphics.getWidth() / 2f;
        float screenY = worldY - playerWorldY + Gdx.graphics.getHeight() / 2f;

        sprite.setPosition(screenX, screenY);
        sprite.draw(Main.getBatch());
    }

    public void updateCollisionRect() {
        collisionRect.move(worldX, worldY); // Keep in world space
    }

    public CollisionRect getCollisionRect() {
        return collisionRect;
    }
}
