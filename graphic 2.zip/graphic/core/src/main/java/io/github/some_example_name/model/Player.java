package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;

import java.util.Random;

public class Player {

    private Texture playerTexture = new Texture(GameAssetManger.getGameAssetManager().getCharacter1_idle0());
    private Sprite playerSprite = new Sprite(playerTexture);
    private float posX = 0;
    private float posY = 0;
    private int kill = 0;
    private float maxHealth;
    private float playerHealth = 5;
    private CollisionRect rect ;
    private float time;
    private float speed = 5;
    private Weapon weapon;
    private int xp = 0;
    private int level = 1;
    private Animation<Texture> playerAnimation;
    private WeaponType weaponType;
    private boolean win = false;
    private boolean abilityActiveSpeed = false;
    private boolean vitalityActive  = false;
    private boolean procreaseActive = false ;
    private boolean amocreaseActive = false ;
    private boolean abilityActiveDamage = false;
    private float abilityTimer = 0f;
    private static final float ABILITY_DURATION = 10f;
    private boolean spawnBoss = false;
    // In Player.java
    private boolean autoAimEnabled = false;
    private boolean invincible = false;
    private float invincibleTimer = 0f;
    private final float INVINCIBLE_DURATION = 1.0f;

    public void setAutoAimEnabled(boolean enabled) {
        autoAimEnabled = enabled;
    }

    public boolean isAutoAimEnabled() {
        return autoAimEnabled;
    }

    private boolean isHit = false;
    private float hitTimer = 0f;
    private static final float HIT_DURATION = 0.2f; // Seconds

    public void gotShot() {
        isHit = true;
        hitTimer = HIT_DURATION;
    }

    public void updateHitState(float delta) {
        if (isHit) {
            hitTimer -= delta;
            if (hitTimer <= 0) {
                isHit = false;
            }
        }
    }

    public boolean isHit() {
        return isHit;
    }



    public float getSpeed() {
        return speed;
    }

    private boolean isPlayerIdle = true;
    private boolean isPlayerRunning = false;


    public Player(){
        playerSprite.setPosition((float) Gdx.graphics.getWidth() / 2, (float) Gdx.graphics.getHeight() / 2);
        playerSprite.setSize(playerTexture.getWidth() * 3, playerTexture.getHeight() * 3);
        rect = new CollisionRect(posX, posY, playerSprite.getWidth(), playerSprite.getHeight());
    }

    public Texture getPlayerTexture() {
        return playerTexture;
    }

    public void setPlayerTexture(Texture playerTexture) {
        this.playerTexture = playerTexture;
    }

    public Sprite getPlayerSprite() {
        return playerSprite;
    }

    public void setPlayerSprite(Sprite playerSprite) {
        this.playerSprite = playerSprite;
    }


    public void addXp(int amount) {
        xp += amount;
        if (xp >= (level) * 20) { // Example: level up every 10 xp
            level++;
            xp = 0;
            System.out.println("Leveled up! New level: " + level);
            // Add level-up effects or bonuses here
        }
    }
    public void applyAbility(AbilityType ability){
        abilityTimer = 0f;
        if(ability.equals(AbilityType.VITALITY)){
            this.increaseHealth();
            this.increaseMaxHealth();
            vitalityActive = true;
        }
        else if(ability.equals(AbilityType.AMOCREASE)){
            weapon.increaseMaxAmmo();
            amocreaseActive = true;
        }
        else if(ability.equals(AbilityType.PROCREASE)){
            weapon.increaseProcrease();
            procreaseActive = true;
        }
        else if(ability.equals(AbilityType.DAMAGER)){
            abilityActiveDamage = true;
            weapon.increaseDamage();
        }
        else if(ability.equals(AbilityType.SPEEDY)){
            abilityActiveSpeed = true;
            doubleSpeed();
        }
    }
    public float getPosX() {
        return posX;
    }
    public float getPosY() {
        return posY;
    }
    public void setPosX(float posX) {
        this.posX = posX;
        rect.move(posX, posY); // keep synced
    }

    public void setPosY(float posY) {
        this.posY = posY;
        rect.move(posX, posY); // keep synced
    }
    public void increaseKill(int amount){
        this.kill += amount;
    }
    public int getKill(){
        return this.kill;
    }
    public float getPlayerHealth() {
        return playerHealth;
    }

    public void setPlayerHealth(float playerHealth) {
        this.playerHealth = playerHealth;
        this.maxHealth = playerHealth;
    }
    public void reduceHealth(float amount){
        this.playerHealth -= amount;
    }
    public CollisionRect getRect() {
        rect.move(posX, posY); // ✅ Use world coordinates!
        return rect;
    }



    public void setRect(CollisionRect rect) {
        this.rect = rect;
    }


    public boolean isPlayerIdle() {
        return isPlayerIdle;
    }

    public void setPlayerIdle(boolean playerIdle) {
        isPlayerIdle = playerIdle;
    }

    public boolean isPlayerRunning() {
        return isPlayerRunning;
    }

    public void setPlayerRunning(boolean playerRunning) {
        isPlayerRunning = playerRunning;
    }

    public float getTime() {
        return time;
    }

    public void setTime(float time) {
        this.time = time;
    }

    public int getXp() {
        return xp;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public void setPlayerAnimation(Animation<Texture> playerAnimation) {
        this.playerAnimation = playerAnimation;
    }

    public Animation<Texture> getPlayerAnimation() {
        return playerAnimation;
    }

    public void setWeaponType(WeaponType weaponType) {
        this.weaponType = weaponType;
    }
    public WeaponType getWeaponType(){
        return weaponType;
    }

    public int getLevel() {
        return level;
    }

    public int getXpToNextLevel() {
        return level * 20 - xp; // Or whatever formula you use
    }

    public boolean isWin() {
        return win;
    }

    public void setWin(boolean win) {
        this.win = win;
    }
    public void increaseLevel(){
        this.level++;
    }
    public void increaseHealth(){
        this.playerHealth++;
    }
    public void increaseSpeed(){
        this.speed++;
    }
    public void increaseMaxHealth(){
        this.maxHealth ++;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public float getAbilityTimer() {
        return abilityTimer;
    }


    public void doubleSpeed(){
        this.speed *=2;
    }
    public void reduceSpeed(){
        this.speed /= 2;
    }
    public void setAbilityTimer(float abilityTimer) {
        this.abilityTimer = abilityTimer;
    }

    public boolean isAbilityActiveDamage() {
        return abilityActiveDamage;
    }

    public boolean isAbilityActiveSpeed() {
        return abilityActiveSpeed;
    }

    public void setAbilityActiveDamage(boolean abilityActiveDamage) {
        this.abilityActiveDamage = abilityActiveDamage;
    }

    public void setAbilityActiveSpeed(boolean abilityActiveSpeed) {
        this.abilityActiveSpeed = abilityActiveSpeed;
    }

    public boolean isAmocreaseActive() {
        return amocreaseActive;
    }

    public boolean isProcreaseActive() {
        return procreaseActive;
    }

    public boolean isVitalityActive() {
        return vitalityActive;
    }

    public float getINVINCIBLE_DURATION() {
        return INVINCIBLE_DURATION;
    }

    public float getInvincibleTimer() {
        return invincibleTimer;
    }

    public boolean isInvincible() {
        return invincible;
    }

    public void setInvincible(boolean invincible) {
        this.invincible = invincible;
    }

    public void setInvincibleTimer(float invincibleTimer) {
        this.invincibleTimer = invincibleTimer;
    }

    public void setSpawnBoss(boolean spawnBoss) {
        this.spawnBoss = spawnBoss;
    }

    public boolean isSpawnBoss() {
        return spawnBoss;
    }
}
