package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import io.github.some_example_name.model.Ability;
import io.github.some_example_name.model.AbilityType;
import io.github.some_example_name.model.App;
import io.github.some_example_name.view.AbilityWindowView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AbilityWindowController {

    private boolean abilityWindowActive = false;
    private final AbilityWindowView abilityWindowView;
    private final Runnable onContinue;
    private final InputProcessor gameInputProcessor;

    // Track which ability is bound to which button
    private final List<AbilityType> shownAbilities = new ArrayList<>();

    public AbilityWindowController(
        AbilityWindowView view,
        Runnable onContinue,
        InputProcessor gameInputProcessor
    ) {
        this.abilityWindowView = view;
        this.onContinue = onContinue;
        this.gameInputProcessor = gameInputProcessor;

        addListeners();
    }

    private void addListeners() {
        abilityWindowView.getAbilityButton1().addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                applyAbilityByIndex(0);
            }
        });

        abilityWindowView.getAbilityButton2().addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                applyAbilityByIndex(1);
            }
        });

        abilityWindowView.getAbilityButton3().addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                applyAbilityByIndex(2);
            }
        });
    }

    private void applyAbilityByIndex(int index) {
        if (index < shownAbilities.size()) {
            AbilityType selectedAbility = shownAbilities.get(index);
           App.getCurrentPlayer().applyAbility(selectedAbility);
        }
        finish();
    }

    private void finish() {
        onContinue.run();
        setAbilityWindowActive(false);
    }

    public void setAbilityWindowActive(boolean active) {
        this.abilityWindowActive = active;
        if (active) {
            showRandomAbilities(); // Generate and show 3 random abilities
            Gdx.input.setInputProcessor(abilityWindowView.getStage());
        } else {
            Gdx.input.setInputProcessor(gameInputProcessor);
        }
    }

    public boolean isAbilityWindowActive() {
        return abilityWindowActive;
    }

    public AbilityWindowView getView() {
        return abilityWindowView;
    }

    private void showRandomAbilities() {
        List<AbilityType> allAbilities = new ArrayList<>();
        Collections.addAll(allAbilities, AbilityType.values());
        Collections.shuffle(allAbilities);
        shownAbilities.clear();

        for (int i = 0; i < 3 && i < allAbilities.size(); i++) {
            shownAbilities.add(allAbilities.get(i));
        }

        abilityWindowView.getAbilityButton1().setText(shownAbilities.get(0).getDisplayName());
        abilityWindowView.getAbilityButton2().setText(shownAbilities.get(1).getDisplayName());
        abilityWindowView.getAbilityButton3().setText(shownAbilities.get(2).getDisplayName());
    }
}
