package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.model.GameAssetManger;

public class AbilityWindowView {
    private final Stage stage;
    private final Skin skin;
    private final Window window;

    private final TextButton abilityButton1;
    private final TextButton abilityButton2;
    private final TextButton abilityButton3;

    public AbilityWindowView() {
        stage = new Stage(new ScreenViewport());
        skin = GameAssetManger.getGameAssetManager().getSkin();

        window = new Window("Choose an Ability", skin);
        window.setModal(true);
        window.setMovable(false);
        window.setResizable(false);
        window.setSize(800, 600);
        window.setPosition(
            (Gdx.graphics.getWidth() - window.getWidth()) / 2f,
            (Gdx.graphics.getHeight() - window.getHeight()) / 2f
        );

        abilityButton1 = new TextButton("Vitality Boost", skin);
        abilityButton2 = new TextButton("Damage Increase", skin);
        abilityButton3 = new TextButton("Speed Boost", skin);

        window.add(abilityButton1).width(300).pad(20).row();
        window.add(abilityButton2).width(300).pad(20).row();
        window.add(abilityButton3).width(300).pad(20).row();

        stage.addActor(window);
    }

    public void draw() {
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }

    public Stage getStage() {
        return stage;
    }

    public TextButton getAbilityButton1() {
        return abilityButton1;
    }

    public TextButton getAbilityButton2() {
        return abilityButton2;
    }

    public TextButton getAbilityButton3() {
        return abilityButton3;
    }

    public Window getWindow() {
        return window;
    }
}
