package io.github.some_example_name.model;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class Avatar {
    public static Image getAvatarByAddress(String address) {
        if(Gdx.files.local("assets/"+address).exists()) {
            Texture texture = new Texture(Gdx.files.local("assets/"+address));
            return new Image(new TextureRegionDrawable(new TextureRegion(texture)));
        }
        System.out.println("file doesn't exist!!");
        return null;
    }
}
