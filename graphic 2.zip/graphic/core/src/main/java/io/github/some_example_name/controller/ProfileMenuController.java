package io.github.some_example_name.controller;

import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.view.AvatarMenuView;
import io.github.some_example_name.view.LoginMenuView;
import io.github.some_example_name.view.MainMenuView;
import io.github.some_example_name.view.ProfileMenuView;

public class ProfileMenuController {
    ProfileMenuView view;

    public void setView(ProfileMenuView view) {
        this.view = view;
    }

    public void handleProfileMenuActions() {
        if (view.getChangeUsernameButton().isPressed()) {
            String username = view.getUsernameField().getText();
            if (App.findUserByUsername(username) == null) {
                App.getCurrentUser().setUsername(username);
                Main.getMain().getScreen().dispose();
                Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            } else {
                view.showError("Username is already taken.");
            }
        } else if (view.getChangePasswordButton().isPressed()) {
            String password = view.getPasswordField().getText();
            if (!password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")) {
                view.showError("Password isn't strong enough.");
            } else {
                App.getCurrentUser().setPassword(password);
                Main.getMain().getScreen().dispose();
                Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
        } else if (view.getDeleteAccountButton().isPressed()) {
            App.getGameUsers().remove(App.getCurrentUser());
            Main.getMain().setScreen(new LoginMenuView(new LoginMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
        } else if (view.getChangeAvatar().isPressed()) {
            Main.getMain().setScreen(new AvatarMenuView(new AvatarMenuController(),GameAssetManger.getGameAssetManager().getSkin()));
        }
    }

}
