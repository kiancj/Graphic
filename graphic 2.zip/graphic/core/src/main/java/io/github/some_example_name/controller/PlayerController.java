package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.utils.TimeUtils;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;

import java.awt.*;



public class PlayerController {
    private Player player;


    public PlayerController(Player player){
        this.player = player;
    }
    public void update(){
        float screenX = Gdx.graphics.getWidth() / 2f;
        float screenY = Gdx.graphics.getHeight() / 2f;
        if (player.isAbilityActiveDamage()) {
            player.setAbilityTimer(player.getAbilityTimer() + Gdx.graphics.getDeltaTime());
            if (player.getAbilityTimer() >= 10f) {
                player.setAbilityActiveDamage(false);
                player.setAbilityTimer(0f);
                player.getWeapon().reduceDamage();
            }
        }
        if (player.isAbilityActiveSpeed()) {
            player.setAbilityTimer(player.getAbilityTimer() + Gdx.graphics.getDeltaTime());
            if (player.getAbilityTimer() >= 10f) {
                player.setAbilityActiveSpeed(false);
                player.setAbilityTimer(0f);
                player.reduceSpeed();
            }
        }
        // ✅ Update hit animation timer
        player.updateHitState(Gdx.graphics.getDeltaTime());
        if (player.isInvincible()) {
            player.setInvincibleTimer(player.getInvincibleTimer()+ Gdx.graphics.getDeltaTime());
            if (player.getInvincibleTimer() >= player.getINVINCIBLE_DURATION()) {
                player.setInvincible(false);
                player.setInvincibleTimer(0f);
            }
        }


        // ✅ Flash red if hit
        if (player.isHit()) {
            player.getPlayerSprite().setColor(1f, 0.2f, 0.2f, 1f); // red
        } else {
            player.getPlayerSprite().setColor(1f, 1f, 1f, 1f); // normal
        }
        Sprite light = GameAssetManger.getGameAssetManager().getLightSprite();
        player.getPlayerSprite().setPosition(screenX, screenY);
        light.setPosition(screenX - 28 , screenY - 28);
        light.draw(Main.getBatch());
        if (!player.isInvincible() || (TimeUtils.nanoTime() / 100_000_000) % 2 == 0) {
            player.getPlayerSprite().draw(Main.getBatch());
        }
        if(player.isPlayerIdle()){
            idleAnimation();
        }

        handlePlayerInput();
    }


    public void handlePlayerInput(){
        float x = player.getPosX();
        float y = player.getPosY();

        if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            y += player.getSpeed(); // ✅ Move up
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S)) {
            y -= player.getSpeed(); // ✅ Move down
        }
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            x -= player.getSpeed(); // ✅ Move left
            if (!player.getPlayerSprite().isFlipX()) {
                player.getPlayerSprite().flip(true, false);
            }
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            x += player.getSpeed(); // ✅ Move right
            if (player.getPlayerSprite().isFlipX()) {
                player.getPlayerSprite().flip(true, false);
            }
        }


        // 🔁 Set new position and update collision rectangle
        player.setPosX(x);
        player.setPosY(y);
        player.getRect().move(x, y);
    }






    public void idleAnimation(){
        Animation<Texture> animation = App.getCurrentPlayer().getPlayerAnimation();

        player.getPlayerSprite().setRegion(animation.getKeyFrame(player.getTime()));

        if (!animation.isAnimationFinished(player.getTime())) {
            player.setTime(player.getTime() + Gdx.graphics.getDeltaTime());
        }
        else {
            player.setTime(0);
        }

        animation.setPlayMode(Animation.PlayMode.LOOP);
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

}
