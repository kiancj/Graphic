package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;

public class Weapon {
    private Sprite smgSprite;
    private int ammo;
    private  int maxAmmo ; // or whatever fits your weapon
    private boolean isReloading = false;
    private float reloadTimer = 0f;
    private  int damage;
    private int procrease = 1;
    private final float reloadTime ;
    private boolean shotgun = false;


    public Weapon() {

        Player player = App.getCurrentPlayer();
        if(player.getWeaponType().equals(WeaponType.REVOLVER)){
            this.ammo = 6;
            this.maxAmmo = 6;
            this.reloadTime = 1f;
            this.damage = 20;
            this.smgSprite = new Sprite(GameAssetManger.getGameAssetManager().getRevolverTexture());
        }
        else if(player.getWeaponType().equals(WeaponType.SHOTGUN)){
            this.maxAmmo = 2;
            this.ammo = 2;
            this.reloadTime = 1f;
            this.damage = 10;
            this.smgSprite = new Sprite(GameAssetManger.getGameAssetManager().getShotgunTexture());
            this.shotgun = true;
        }
        else{
            this.maxAmmo = 24;
            this.ammo = 24;
            this.damage = 8;
            this.reloadTime = 2f;
            this.smgSprite = new Sprite(GameAssetManger.getGameAssetManager().getSmgTexture());
        }
        smgSprite.setX((float) Gdx.graphics.getWidth() / 2);
        smgSprite.setY((float) Gdx.graphics.getHeight() / 2);
        smgSprite.setSize(50, 50);
    }

    public Sprite getSmgSprite() {
        return smgSprite;
    }

    public void setGunSprite(Sprite smgSprite) {
        this.smgSprite = smgSprite;
    }

    public int getAmmo() {
        return ammo;
    }

    public void setAmmo(int ammo) {
        this.ammo = ammo;
    }

    public int getMaxAmmo() {
        return maxAmmo;
    }

    public boolean isReloading() {
        return isReloading;
    }

    public void setReloading(boolean reloading) {
        isReloading = reloading;
    }

    public float getReloadTimer() {
        return reloadTimer;
    }

    public void setReloadTimer(float reloadTimer) {
        this.reloadTimer = reloadTimer;
    }

    public float getReloadTime() {
        return reloadTime;
    }

    public boolean isShotgun() {
        return shotgun;
    }

    public void setShotgun(boolean shotgun) {
        this.shotgun = shotgun;
    }

    public int getDamage() {
        return damage;
    }
    public void increaseMaxAmmo(){
        this.maxAmmo += 5;
    }
    public void increaseProcrease(){
        this.procrease ++;
    }

    public int getProcrease() {
        return procrease;
    }
    public void increaseDamage(){
        this.damage += this.damage/4;
    }
    public void reduceDamage(){
        this.damage -=  this.damage/5;
    }
}
