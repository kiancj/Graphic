package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.HintMenuController;
import io.github.some_example_name.controller.ScoreBoardController;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.User;

import java.util.List;

public class HintMenuView implements Screen {
    private Stage stage;
    private Table table;
    private Table table1;
    private final Label scoreboard;
    private final HintMenuController controller;
    private final Skin skin;
    private final TextButton button;
    private final Label user1 ;
    private final Label user2 ;
    private final Label user3 ;
    private final Label user4 ;
    private final Label user5 ;
    private final Label user6 ;
    private final Label user7 ;
    private final Label user8 ;
    private final Label user9 ;
    private final Label user10 ;
    private final Label user11;
    private final Label user12;





    public HintMenuView(HintMenuController controller, Skin skin) {
        this.controller = controller;
        this.skin = skin;
        scoreboard = new Label("Hint Menu",skin);
        user1 = new Label("SHANA : HP : 4 , SPEED : 4",skin);
        user2 = new Label("SCARLET : HP : 3 , SPEED : 5",skin);
        user3 = new Label("DASHER : HP : 2 , SPEED : 10",skin);
        user4 = new Label("HEROS INFO",skin);
        user5 = new Label("KEYS",skin);
        user6 = new Label("W : UP , S : DOWN , D : RIGHT , A : LEFT , R : RELOAD",skin);
        user7 = new Label("CHEAT CODES",skin);
        user8 = new Label("B : BossFight U : increase speed , L : increase level , H : get hp , P : for decreasing game time",skin);
        user9 = new Label("ABILITIES",skin);
        user10 = new Label("Vitality : Increase one hp , Damager : increase damage for 10 seconds",skin);
        user11 = new Label("Procrease : Increase projectile by one , Amocrease : increase ammo by 5",skin);
        user12 = new Label("Speedy : double the speed for 10 seconds",skin);
        scoreboard.setColor(Color.BLUE);
        user1.setColor(Color.GOLD);
        user2.setColor(Main.SILVER);
        user3.setColor(Color.BROWN);
        user10.setColor(Color.CORAL);
        user11.setColor(Color.CORAL);
        user12.setColor(Color.CORAL);
        button = new TextButton("Main Menu",skin);
        controller.setView(this);

    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        table = new Table(skin);
        table1 = new Table(skin);
        table.setFillParent(true);
        table.right();
        table.row().pad(10, 0 , 10 , 0);
        table.add(button);
        button.setColor(Color.WHITE);
        stage.addActor(table);
        table1.setFillParent(true);
        table1.left();
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(scoreboard);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user4);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user1);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user2);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user3);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user5);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user6);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user7);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user8);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user9);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user10);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user11);
        table1.row().pad(10, 0 , 10 , 0);
        table1.add(user12);
        stage.addActor(table1);
    }



    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        controller.handleButtons();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    public Label getUser10() {
        return user10;
    }

    public Label getUser9() {
        return user9;
    }

    public Label getUser8() {
        return user8;
    }

    public Label getUser7() {
        return user7;
    }

    public Label getUser6() {
        return user6;
    }

    public Label getUser5() {
        return user5;
    }

    public Label getUser4() {
        return user4;
    }

    public Label getUser3() {
        return user3;
    }

    public Label getUser2() {
        return user2;
    }

    public Label getUser1() {
        return user1;
    }

    public TextButton getButton() {
        return button;
    }
}
