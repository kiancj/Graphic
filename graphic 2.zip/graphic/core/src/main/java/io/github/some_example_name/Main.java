package io.github.some_example_name;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.some_example_name.controller.LoginMenuController;
import io.github.some_example_name.controller.MainMenuController;
import io.github.some_example_name.model.*;
import io.github.some_example_name.view.LoginMenuView;
import io.github.some_example_name.view.MainMenuView;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {
    public static final Color SILVER = new Color(0.75f, 0.75f, 0.75f, 1f);
    private static AvatarPathProvider avatarPathProvider = new AvatarPathProvider();
    private static Main main;
    private static SpriteBatch batch;
    private static Music music;
    public static Music getMusic() {
        return music;
    }

    public static void setMusic(Music newMusic) {
        if (music != null) {
            music.stop();
            music.dispose();
        }
        music = newMusic;
    }

    @Override
    public void create() {
        main = this;
        UserDataList allUsers = UserSaveManager.loadUserDataList();
        if (allUsers != null) {
            for (UserData u : allUsers.users) {
                System.out.println("Loaded user: " + u.username);
            }
        }
//        User user1 = new User("kian","Kiangh84@","salam");
//        User user2 = new User("reza","Rezagh66@","salam");
//        User user3 = new User("Ali","Aligh59@","salam");
//        User user4 = new User("Abbas","Abbasgh54@","salam");
//        User user5 = new User("Mamad","Mamadgh66@","salam");
//        user1.setKills(100);
//        user1.setScore(300);
//        user1.setMostTimeStayedAlive(200);
//        user2.setKills(150);
//        user2.setScore(200);
//        user2.setMostTimeStayedAlive(100);
//        user3.setKills(180);
//        user3.setScore(390);
//        user3.setMostTimeStayedAlive(290);
//        user4.setKills(109);
//        user4.setScore(309);
//        user4.setMostTimeStayedAlive(290);
//        user5.setKills(169);
//        user5.setScore(369);
//        user5.setMostTimeStayedAlive(296);
//        App.getGameUsers().add(user1);
//        App.getGameUsers().add(user2);
//        App.getGameUsers().add(user3);
//        App.getGameUsers().add(user4);
//        App.getGameUsers().add(user5);
        batch = new SpriteBatch();
        music = GameAssetManger.getGameAssetManager().getBackgroundMusic1();
        music.setLooping(true);
        music.setVolume(0.5f);
        music.play();
       // getMain().setScreen(new MainMenuView(new MainMenuController() , GameAssetManger.getGameAssetManager().getSkin()));
       getMain().setScreen(new LoginMenuView(new LoginMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
    }

    @Override
    public void render() {
        super.render();
    }

    @Override
    public void dispose() {
        batch.dispose();
    }

    public static Main getMain() {
        return main;
    }

    public static void setMain(Main main) {
        Main.main = main;
    }

    public static SpriteBatch getBatch() {
        return batch;
    }

    public static void setBatch(SpriteBatch batch) {
        Main.batch = batch;
    }
    public static AvatarPathProvider getAvatarPathProvider() {
        return avatarPathProvider;
    }
    public Color getSilver(){
        return SILVER;
    }
}
