package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;

public class ShooterEnemy {
    private Sprite sprite;
    private CollisionRect collisionRect;
    private boolean alive = true;
    private float worldX, worldY;
    private float shootTimer = 0f;
    private int hp = 50;
    private boolean dying = false;
    private float animationTimer = 0f;
    private float deathTimer = 0f;
    private Animation<Texture> walkAnimation;
    private float deathDuration = 0.5f; // Adjust as needed
    private Animation<Texture> deathAnimation = GameAssetManger.getGameAssetManager().getDeath_frame();
    private Vector2 knockbackVelocity = new Vector2(0, 0);
    private float knockbackTimer = 0f;
    private final float knockbackDuration = 0.1f; // ~100 ms
    public void updateDeathAnimation(float delta) {
        if (dying) {
            deathTimer += delta;
        }
    }

    public boolean isDying() {
        return dying;
    }

    public boolean shouldBeRemoved() {
        return !alive && deathTimer >= deathDuration;
    }

    public void die() {
        alive = false;
        dying = true;
        deathTimer = 0;
    }

    public Texture getCurrentDeathFrame() {
        return deathAnimation.getKeyFrame(deathTimer, false);
    }

    public void setWorldX(float x) { worldX = x; }
    public void setWorldY(float y) { worldY = y; }

    public void updateCollisionRect(Player player) {
        float screenX = worldX - player.getPosX() + Gdx.graphics.getWidth() / 2f;
        float screenY = worldY - player.getPosY() + Gdx.graphics.getHeight() / 2f;
        // Assume your enemy has a method to set collision rect position here
        getCollisionRect().setX(screenX);
        getCollisionRect().setY(screenY);
    }


    public ShooterEnemy(float x, float y) {
        this.worldX = x;
        this.worldY = y;

        Texture enemy0Tex = new Texture("WingedMonster/WingedMonster_0.png");
        Texture enemy1Tex = new Texture("WingedMonster/WingedMonster_1.png");
        Texture enemy2Tex = new Texture("WingedMonster/WingedMonster_2.png");
        Texture enemy3Tex = new Texture("WingedMonster/WingedMonster_3.png");
        Texture enemy4Tex = new Texture("WingedMonster/WingedMonster_4.png");

        walkAnimation = new Animation<>(0.1f, enemy0Tex, enemy1Tex, enemy2Tex, enemy3Tex, enemy4Tex);
        this.sprite = new Sprite(enemy0Tex);
        sprite.setSize(32, 32); // Adjust size here, AFTER initialization
        sprite.setPosition(x, y);

        collisionRect = new CollisionRect(x, y, sprite.getWidth(), sprite.getHeight());
    }


    public void update(float delta) {
        shootTimer += delta;
        animationTimer += delta;
        if (knockbackTimer > 0) {
            float knockbackSpeed = 2f; // Adjust to control how fast it moves back
            worldX += knockbackVelocity.x * knockbackSpeed * delta;
            worldY += knockbackVelocity.y * knockbackSpeed * delta;
            knockbackTimer -= delta;
        }
    }

    public boolean readyToShoot() {
        return shootTimer >= 3f;
    }

    public void resetShootTimer() {
        shootTimer = 0f;
    }

    public void takeDamage(int dmg) {
        hp -= dmg;
        if (hp <= 0) alive = false;
    }

    public boolean isAlive() {
        return alive;
    }

    public Sprite getSprite() {
        return sprite;
    }

    public CollisionRect getCollisionRect() {
        collisionRect.move(worldX, worldY);
        return collisionRect;
    }

    public float getWorldX() {
        return worldX;
    }

    public float getWorldY() {
        return worldY;
    }

    public void setWorldPosition(float x, float y) {
        this.worldX = x;
        this.worldY = y;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }
    public Texture getCurrentFrame() {
        return walkAnimation.getKeyFrame(animationTimer, true); // true = loop
    }
    public void applyKnockback(Vector2 knockback) {
        this.knockbackVelocity.set(knockback);
        this.knockbackTimer = knockbackDuration;
    }


}
