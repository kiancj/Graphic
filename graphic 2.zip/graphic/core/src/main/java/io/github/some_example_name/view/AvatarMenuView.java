package io.github.some_example_name.view;


import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.AvatarMenuController;
import io.github.some_example_name.model.AvatarPathProvider;


import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AvatarMenuView implements Screen {
    private Stage stage;
    private final TextButton backButton;
    private final Label title;

    private final TextButton selectAvatarButton;
    private final Image avatarPreview;
    private FileHandle selectedAvatarFile;
    private final TextButton submitButton;
    private final SelectBox avatarOptions;
    private final TextButton submitLocalButton;
    public final Texture background;


    private final AvatarMenuController controller;
    public Table table;

    public AvatarMenuView(AvatarMenuController controller, Skin skin) {
        this.controller = controller;
        this.backButton = new TextButton("Back", skin);
        this.title = new Label("Avatar Menu", skin);
        background = new Texture("wallpaper.png");

        this.selectAvatarButton = new TextButton("Select Image", skin);
        this.submitLocalButton = new TextButton("Submit Local Avatar", skin);
        this.avatarPreview = new Image();
        this.submitButton = new TextButton("Submit", skin);
        this.avatarOptions = new SelectBox<>(skin);



        this.table = new Table();
        controller.setView(this);
    }

    private void showFileChooser() {
        if (Gdx.app.getType() != Application.ApplicationType.Desktop) {
            Gdx.app.log("FileChooser", "File selection only supported on desktop");
            return;
        }

        java.awt.EventQueue.invokeLater(() -> {
            FileDialog fileDialog = new FileDialog((Frame) null, "Select Avatar Image", FileDialog.LOAD);
            fileDialog.setFilenameFilter((dir, name) -> name.toLowerCase().matches(".*\\.(png|jpg|jpeg)"));
            fileDialog.setMultipleMode(false);  // safer for macOS
            fileDialog.setVisible(true);

            if (fileDialog.getFile() != null) {
                String filePath = fileDialog.getDirectory() + fileDialog.getFile();
                selectedAvatarFile = Gdx.files.absolute(filePath);
                Gdx.app.postRunnable(this::updateAvatarPreview);  // Ensure this runs on the render thread
            }
        });
    }

    private Texture previewTexture;

    private void updateAvatarPreview() {
        if (selectedAvatarFile != null && selectedAvatarFile.exists()) {
            if (previewTexture != null) previewTexture.dispose();  // dispose old texture
            try {
                previewTexture = new Texture(selectedAvatarFile);
                avatarPreview.setDrawable(new TextureRegionDrawable(new TextureRegion(previewTexture)));
                float aspectRatio = (float) previewTexture.getWidth() / previewTexture.getHeight();
                float width = 200;
                float height = width / aspectRatio;
                avatarPreview.setSize(width, height);
            } catch (Exception e) {
                Gdx.app.error("AvatarPreview", "Error loading image: " + e.getMessage());
            }
        }
    }






    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        title.setFontScale(1.5f);

        avatarOptions.setItems(controller.getAvatarNames());


        table.setFillParent(true);
//        table.setDebug(true);
        table.center();
        table.add(title).colspan(2).center();
        table.row().pad(10, 0, 10, 0);
        table.add(avatarOptions).colspan(2).center();
        table.row().pad(10, 0, 40, 0);
        table.add(submitLocalButton).colspan(2).center();
        table.row().pad(10, 0, 10, 0);
        table.add(selectAvatarButton).colspan(2).center();
        table.row().pad(10, 0, 10, 0);
        table.add(avatarPreview).colspan(2).center();
        table.row().pad(10, 0, 10, 0);
        table.add(submitButton).colspan(2).center();
        table.row().pad(40, 0, 10, 0);
        table.add(backButton).colspan(2).center();

        selectAvatarButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent changeEvent, Actor actor) {
                if (Gdx.app.getType() == Application.ApplicationType.Desktop) {
                    showFileChooser();
                } else {
                    Gdx.app.log("FileChooser", "File selection only supported on desktop");
                }
            }
        });


        stage.addActor(table);
    }


    @Override
    public void render(float v) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        controller.handleButtons();
        AvatarPathProvider provider = Main.getAvatarPathProvider();
        if(!provider.getAvatarPath().equals(provider.getPrevAvatarPath())){
            provider.setPrevAvatarPath();
            controller.dragAndDropPath(provider.getAvatarPath());
            System.out.println(provider.getAvatarPath());
        }
    }

    @Override
    public void resize(int i, int i1) {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        if (previewTexture != null) previewTexture.dispose();
        background.dispose();
        if (stage != null) stage.dispose();
    }


    public Stage getStage() {
        return stage;
    }

    public TextButton getBackButton() {
        return backButton;
    }

    public Label getTitle() {
        return title;
    }

    public AvatarMenuController getController() {
        return controller;
    }

    public Table getTable() {
        return table;
    }

    public TextButton getSelectAvatarButton() {
        return selectAvatarButton;
    }

    public Image getAvatarPreview() {
        return avatarPreview;
    }

    public FileHandle getSelectedAvatarFile() {
        return selectedAvatarFile;
    }

    public TextButton getSubmitButton() {
        return submitButton;
    }

    public SelectBox getAvatarOptions() {
        return avatarOptions;
    }

    public TextButton getSubmitLocalButton() {
        return submitLocalButton;
    }
}
