package io.github.some_example_name.model;

import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;

import java.util.Random;

public class User {
    private String username;
    private String password;
    private String schoolName;
    private String avatarAddress;
    private Music music;
    private boolean autoReload = false;
    private int score;
    private final Texture character1_idle0_tex;
    private int kills;
    private int mostTimeStayedAlive;
    private boolean rememberMe;
    private boolean sfxActive = true;

    public User(String username, String password, String schoolName) {
        this.username = username;
        this.password = password;
        this.rememberMe = true;
        this.kills = 0;
        this.mostTimeStayedAlive = 0;
        this.score = 0;
        this.music = GameAssetManger.getGameAssetManager().getBackgroundMusic1();
        Random number = new Random();
        int num = number.nextInt(4);
        switch (num) {
            case 0:
                avatarAddress = GameAssetManger.getGameAssetManager().getCharacter1_idle0();
                break;
            case 1:
                avatarAddress = GameAssetManger.getGameAssetManager().getDiddy();
                break;
            case 2:
                avatarAddress = GameAssetManger.getGameAssetManager().getYuz();
                break;
            case 3:
                avatarAddress = GameAssetManger.getGameAssetManager().getGolzar();
                break;
        }
        character1_idle0_tex = new Texture(avatarAddress);
        this.schoolName = schoolName;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getScore() {
        return score;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Texture getCharacter1_idle0_tex() {
        return character1_idle0_tex;
    }

    public String getAvatarAddress() {
        return avatarAddress;
    }

    public void setAvatarAddress(String avatarAddress) {
        this.avatarAddress = avatarAddress;
    }

    public Music getMusic() {
        return music;
    }

    public void setMusic(Music music) {
        this.music = music;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getKills() {
        return kills;
    }

    public int getMostTimeStayedAlive() {
        return mostTimeStayedAlive;
    }

    public boolean isRememberMe() {
        return rememberMe;
    }

    public void setMostTimeStayedAlive(int mostTimeStayedAlive) {
        this.mostTimeStayedAlive = mostTimeStayedAlive;
    }

    public void setKills(int kills) {
        this.kills = kills;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void increaseKill(int kill) {
        this.kills += kill;
    }

    public void increaseScore(int points) {
        this.score += points;
    }

    public boolean isAutoReload() {
        return autoReload;
    }

    public void setAutoReload(boolean autoReload) {
        this.autoReload = autoReload;
    }

    public boolean isSfxActive() {
        return sfxActive;
    }

    public void setSfxActive(boolean sfxActive) {
        this.sfxActive = sfxActive;
    }
}
