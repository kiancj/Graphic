package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;

import java.util.ArrayList;
import java.util.Iterator;

public class ShooterEnemyController {

    private final ArrayList<ShooterEnemy> shooterEnemies = new ArrayList<>();
    private final PlayerController playerController;
    private final ArrayList<EnemyBullet> enemyBullets = new ArrayList<>();
    private final ArrayList<XpDot> xpDots = new ArrayList<>();
    private final WeaponController weaponController;



    private float elapsedTime = 0;
    private float spawnTimer = 0;
    private float spawnRate = 5f;

    public ShooterEnemyController(PlayerController playerController , WeaponController weaponController) {
        this.playerController = playerController;
        this.weaponController = weaponController;
    }

    public void update(float delta) {
        elapsedTime += delta;
        spawnTimer += delta;

        // Spawn shooter enemies around the player
        if (spawnTimer >= spawnRate) {
            spawnShooterEnemy();
            spawnTimer = 0f;
        }

        Player player = playerController.getPlayer();

        // Update enemies
        Iterator<ShooterEnemy> iter = shooterEnemies.iterator();
        while (iter.hasNext()) {
            ShooterEnemy e = iter.next();

            // Move toward player
            Vector2 enemyPos = new Vector2(e.getWorldX(), e.getWorldY());
            Vector2 playerPos = new Vector2(player.getPosX(), player.getPosY());
            Vector2 direction = playerPos.sub(enemyPos).nor();
            float speed = 50f;
            e.setWorldX(e.getWorldX() + direction.x * speed * delta);
            e.setWorldY(e.getWorldY() + direction.y * speed * delta);

            e.update(delta);
            e.updateCollisionRect(player);

            float screenX = e.getWorldX() - player.getPosX() + Gdx.graphics.getWidth() / 2f;
            float screenY = e.getWorldY() - player.getPosY() + Gdx.graphics.getHeight() / 2f;
            e.getSprite().setPosition(screenX, screenY);
            Main.getBatch().draw(
                e.getCurrentFrame(),
                e.getSprite().getX(),
                e.getSprite().getY(),
                e.getSprite().getWidth(),
                e.getSprite().getHeight()
            );


            // 💥 Bullet collision detection
            for (Bullet bullet : weaponController.getBullets()) {
                if (bullet.getCollisionRect() != null && e.getCollisionRect() != null) {
                    if (e.getCollisionRect().collidesWith(bullet.getCollisionRect())) {
                        e.takeDamage(weaponController.getWeapon().getDamage());
                        // 🧠 Compute knockback direction
                        float bulletWorldX = bullet.getSprite().getX() - Gdx.graphics.getWidth() / 2f + player.getPosX();
                        float bulletWorldY = bullet.getSprite().getY() - Gdx.graphics.getHeight() / 2f + player.getPosY();

                        Vector2 EnemyPos = new Vector2(e.getWorldX(), e.getWorldY());
                        Vector2 bulletPos = new Vector2(bulletWorldX, bulletWorldY);
                        Vector2 knockbackDir = EnemyPos.cpy().sub(bulletPos).nor(); // Enemy pushed away from bullet

                        float knockbackDistance = 30f; // You can adjust this
                        e.setWorldX(e.getWorldX() + knockbackDir.x * knockbackDistance);
                        e.setWorldY(e.getWorldY() + knockbackDir.y * knockbackDistance);
                        weaponController.getBullets().remove(bullet); // ✅ remove bullet after hitting
                        break;
                    }
                }
            }

            // 💀 If dead, drop XP and remove
            if (!e.isAlive()) {
                if (!e.isDying()) {
                    float worldX = e.getSprite().getX() - Gdx.graphics.getWidth() / 2f + playerController.getPlayer().getPosX();
                    float worldY = e.getSprite().getY() - Gdx.graphics.getHeight() / 2f + playerController.getPlayer().getPosY();
                    xpDots.add(new XpDot(worldX, worldY));
                    App.getCurrentUser().increaseKill(1);
                    playerController.getPlayer().increaseKill(1);
                    if(App.getCurrentUser().isSfxActive()){
                        GameAssetManger.getGameAssetManager().getEnemyKilled().play();
                    }
                    e.die(); // Start the animation
                } else {
                    e.updateDeathAnimation(delta);
                    Main.getBatch().draw(e.getCurrentDeathFrame(), e.getSprite().getX(), e.getSprite().getY());

                    if (e.shouldBeRemoved()) {
                        iter.remove();
                    }
                }
                continue;
            }


            // 💣 Shoot if ready
            if (e.readyToShoot()) {
                if(App.getCurrentUser().isSfxActive()){
                    GameAssetManger.getGameAssetManager().getShoot().play();
                }
                shootBulletAtPlayer(e);
                e.resetShootTimer();
            }

            // 🧍 Collision with player
            if (e.getCollisionRect().collidesWith(player.getRect()) && !player.isInvincible()) {
                player.reduceHealth(1);
                playerController.getPlayer().setInvincible(true);
                GameAssetManger.getGameAssetManager().getEnemyKilled().play();
                e.setAlive(false);
                iter.remove();
            }
        }


        Iterator<EnemyBullet> bulletIter = enemyBullets.iterator();
        while (bulletIter.hasNext()) {
            EnemyBullet b = bulletIter.next();
            b.update(delta);
            b.draw(player.getPosX(), player.getPosY());

            if (b.isOffScreen(player.getPosX(), player.getPosY())) {
                bulletIter.remove();
            } else if (b.getCollisionRect().collidesWith(player.getRect())) {
                if(player.isInvincible()){
                    return;
                }
                player.reduceHealth(1);
                player.gotShot();
                bulletIter.remove();
            }
        }

        Iterator<XpDot> xpIterator = xpDots.iterator();
        while (xpIterator.hasNext()) {
            XpDot dot = xpIterator.next();

            dot.updateCollisionRect();
            if (dot.getCollisionRect().collidesWith(player.getRect())) {
                if(App.getCurrentUser().isSfxActive()){
                    GameAssetManger.getGameAssetManager().getCoins().play();
                }
                dot.collect();
                player.addXp(3);
                xpIterator.remove();
            } else {
                dot.draw(Main.getBatch(), player.getPosX(), player.getPosY());
            }
        }

    }
    public ShooterEnemy getNearestEnemy(float playerX, float playerY) {
        ShooterEnemy nearest = null;
        float minDistSq = Float.MAX_VALUE;

        for (ShooterEnemy enemy : shooterEnemies) {
            if (!enemy.isAlive() || enemy.isDying()) continue;

            float dx = enemy.getWorldX() - playerX;
            float dy = enemy.getWorldY() - playerY;
            float distSq = dx * dx + dy * dy;

            if (distSq < minDistSq) {
                minDistSq = distSq;
                nearest = enemy;
            }
        }

        return nearest;
    }

    private void spawnShooterEnemy() {
        Player player = playerController.getPlayer();
        float px = player.getPosX();
        float py = player.getPosY();

        // Spawn within 300–500 units radius around the player
        float angle = MathUtils.random(0f, 360f);
        float distance = MathUtils.random(300f, 500f);

        float x = px + MathUtils.cosDeg(angle) * distance;
        float y = py + MathUtils.sinDeg(angle) * distance;

        shooterEnemies.add(new ShooterEnemy(x, y));
    }

    private void shootBulletAtPlayer(ShooterEnemy shooter) {
        float shooterX = shooter.getWorldX();
        float shooterY = shooter.getWorldY();
        float playerX = playerController.getPlayer().getPosX();
        float playerY = playerController.getPlayer().getPosY();

        EnemyBullet bullet = new EnemyBullet(shooterX, shooterY, playerX, playerY);
        enemyBullets.add(bullet);
    }









    public ArrayList<ShooterEnemy> getShooterEnemies() {
        return shooterEnemies;
    }
}
