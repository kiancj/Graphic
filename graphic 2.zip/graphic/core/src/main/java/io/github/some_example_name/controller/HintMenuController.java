package io.github.some_example_name.controller;

import io.github.some_example_name.Main;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.view.HintMenuView;
import io.github.some_example_name.view.MainMenuView;


public class HintMenuController {
    HintMenuView view;
    public void setView(HintMenuView view) {
        this.view = view;
    }
    public void handleButtons(){
        if(view.getButton().isPressed()){
            Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
        }
    }
}
