package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.EndMenuController;
import io.github.some_example_name.controller.LoginMenuController;
import io.github.some_example_name.controller.MainMenuController;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.UserSaveManager;

public class EndMenuView implements Screen {
    private Stage stage;
    private final TextButton playButton;
    private final Label result;
    private final Label username;
    private final Label playTime;
    private final Label totalKill;
    private final Label score;
    public Table table;
    private final EndMenuController controller;
    private final Texture background;

    public EndMenuView(EndMenuController controller, Skin skin , float playTime) {
        this.controller = controller;
        this.table = new Table();
        this.username = new Label("Username: "+ App.getCurrentUser().getUsername(),skin);
        this.totalKill = new Label("Total Kills: " + App.getCurrentPlayer().getKill(),skin);
        this.playTime = new Label("Survival Time: "+playTime,skin);
        App.getCurrentUser().increaseScore((int) (App.getCurrentPlayer().getKill() * playTime));
        this.score = new Label("Score: "+ App.getCurrentPlayer().getKill() * playTime,skin);
        controller.setView(this , skin);
        background = new Texture("wallpaper.png");
        this.playButton = new TextButton("GO To Main Menu",skin);
        this.result = new Label("",skin);
        if(App.getCurrentPlayer().isWin()){
            result.setColor(Color.GREEN);
            result.setText("WIN");
        }
        else{
            result.setText("DEAD");
            result.setColor(Color.RED);
        }
        UserSaveManager.saveUser(App.getCurrentUser());
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        table.setFillParent(true);
        table.center();
        table.row().pad(5, 0 , 5 , 0);
        table.add(result).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(username).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(playTime).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(totalKill).width(600);
        table.row().pad(5, 0 , 5 , 0);
        table.add(score).width(600);
        table.row();
        table.add(playButton).size(500, 40).pad(10);
        table.row();
        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        controller.handleMainMenuButtons();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public TextButton getPlayButton() {
        return playButton;
    }



}
