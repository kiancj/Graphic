package io.github.some_example_name.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class UserSaveManager {
    private static final String SAVE_FILE = "user_data.json";

    // Save or update a user inside the JSON list
    public static void saveUser(User user) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        // Load existing users list or create new if none exists
        UserDataList userList = loadUserDataList();
        if (userList == null) {
            userList = new UserDataList();
        }

        // Convert User to UserData
        UserData newUserData = new UserData(user);

        // Remove any existing user with the same username to update
        userList.users.removeIf(u -> u.username.equals(newUserData.username));

        // Add new/updated user
        userList.users.add(newUserData);

        // Save back to file
        try (FileWriter writer = new FileWriter(SAVE_FILE)) {
            gson.toJson(userList, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load all users as a list
    public static UserDataList loadUserDataList() {
        Gson gson = new Gson();

        try (FileReader reader = new FileReader(SAVE_FILE)) {
            return gson.fromJson(reader, UserDataList.class);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}


