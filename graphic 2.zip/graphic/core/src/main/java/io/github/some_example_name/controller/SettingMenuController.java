package io.github.some_example_name.controller;

import com.badlogic.gdx.audio.Music;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.view.MainMenuView;
import io.github.some_example_name.view.SettingMenuView;
import io.github.some_example_name.view.SignUpMenuView;

public class SettingMenuController {
    SettingMenuView view;

    public void setView(SettingMenuView view){
        this.view = view;
    }
    public void handleSettingButtons(String sfx , String auto){
        if(view.getConfirm().isPressed()){
            String volumeAmount = view.getVolumeField().getText();
            String musicNumber = view.getMusicNumber().getText();
            Music newMusic;
            if(musicNumber.equals("2")){
                newMusic = GameAssetManger.getGameAssetManager().getBackgroundMusic2();
            }
            else{
                newMusic = GameAssetManger.getGameAssetManager().getBackgroundMusic1();
            }
            newMusic.setLooping(true);
            newMusic.setVolume(0.5f);
            newMusic.play();
            Main.setMusic(newMusic);
            if(volumeAmount.matches("^\\d+$")){
                int amount = Integer.parseInt(volumeAmount);
                float Amount = (float) amount /100;
                Main.getMusic().setVolume(Amount);
            }
            else{
                App.getCurrentUser().getMusic().setVolume(0.5f);
            }
            if(auto.equals("ON")){
                App.getCurrentUser().setAutoReload(true);
            }
//            if(sfx.equals("OFF")){
//                App.getCurrentUser().setSfxActive(false);
//            }
            Main.getMain().getScreen().dispose();
            Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
        }
    }
}
