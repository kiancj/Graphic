package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.MainMenuController;
import io.github.some_example_name.controller.SignUpMenuController;

public class SignUpMenuView implements Screen {
    private Stage stage;
    private final TextButton playButton;
    private final TextButton playButton1;
    private final TextField field;
    private final TextField field1;
    private final TextField field2;
    private final Label label;
    private final Label label1;
    public Table table;
    private final SignUpMenuController controller;

    public SignUpMenuView(SignUpMenuController controller, Skin skin) {
        this.controller = controller;
        this.playButton = new TextButton("Sign Up", skin);
        this.playButton1 = new TextButton("Play as guest", skin);
        this.field = new TextField("Enter Username", skin);
        this.field1 = new TextField("Enter Password", skin);
        this.label = new Label("Security Question",skin);
        this.field2 = new TextField("Enter the name of your school", skin);
        this.label1 = new Label("",skin);
        this.table = new Table();


        controller.setView(this, skin);
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        table.setFillParent(true);
        table.center();
        table.row().pad(10, 0 , 10 , 0);
        table.add(label1).width(600);
        table.row().pad(10, 0 , 10 , 0);
        table.add(field).width(600);
        table.row().pad(10, 0 , 10 , 0);
        table.add(field1).width(600);
        table.row().pad(10, 0 , 10 , 0);
        table.add(label);
        table.row().pad(10, 0 , 10 , 0);
        table.add(field2).width(600);
        table.row();
        table.add(playButton).size(500, 40).pad(10);
        table.row();
        table.add(playButton1).size(500, 40).pad(10);
        label1.setColor(Color.RED);
        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        controller.handleSignUpMenuButtons();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public TextButton getPlayButton() {
        return playButton;
    }
    public TextButton getPlayButton1() {
        return playButton1;
    }

    public TextField getField() {
        return field;
    }
    public TextField getField1() {
        return field1;
    }
    public TextField getField2() {
        return field2;
    }
    public Label getLabel1(){
        return label1;
    }


}
