package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;

public class Bullet {
    private Texture texture = new Texture(GameAssetManger.getGameAssetManager().getBullet());
    private Sprite sprite = new Sprite(texture);
    private int x;
    private int y;
    private final float speed = 10f;
    private int damage = 3;
    private CollisionRect collisionRect;
    private float directionX;
    private float directionY;
    private boolean usesFixedDirection = false;
    private Vector2 direction;

// In constructor, after calculating target:



    public Bullet(int x, int y){
        sprite.setSize(20 , 20);
        this.x = x;
        this.y = y;
        sprite.setX((float) Gdx.graphics.getWidth() / 2);
        sprite.setY((float) Gdx.graphics.getHeight() / 2);
        float startX = Gdx.graphics.getWidth() / 2f;
        float startY = Gdx.graphics.getHeight() / 2f;

        sprite.setX(startX);
        sprite.setY(startY);

        float dx = x - startX;
        float dy = y - startY;
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        if (length != 0) {
            directionX = dx / length;
            directionY = dy / length;
        } else {
            directionX = 0;
            directionY = 0;
        }
        this.direction = new Vector2(directionX, directionY);
        usesFixedDirection = true;
        collisionRect = new CollisionRect(sprite.getX(), sprite.getY(), sprite.getWidth(), sprite.getHeight());

    }


    public void updatePosition(float playerWorldX, float playerWorldY) {
        float dirX = Gdx.graphics.getWidth() / 2f - x;
        float dirY = Gdx.graphics.getHeight() / 2f - y;
        float length = (float) Math.sqrt(dirX * dirX + dirY * dirY);

        dirX /= length;
        dirY /= length;

        sprite.setX(sprite.getX() - dirX * speed);
        sprite.setY(sprite.getY() + dirY * speed);

        // Convert bullet screen position to world coordinates
        float worldX = sprite.getX() - Gdx.graphics.getWidth() / 2f + playerWorldX;
        float worldY = sprite.getY() - Gdx.graphics.getHeight() / 2f + playerWorldY;

        if (collisionRect != null) {
            collisionRect.move(worldX, worldY); // ✅ WORLD COORDS!
        }
    }



    public boolean isOffScreen() {
        return sprite.getX() < -20 || sprite.getX() > Gdx.graphics.getWidth() + 20 ||
            sprite.getY() < -20 || sprite.getY() > Gdx.graphics.getHeight() + 20;
    }

    public Sprite getSprite() {
        return sprite;
    }

    public CollisionRect getCollisionRect() {
        return collisionRect;
    }

    public int getDamage() {
        return damage;
    }

    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }

    public Vector2 getDirection() {
        return new Vector2(directionX, directionY).nor();
    }


}
