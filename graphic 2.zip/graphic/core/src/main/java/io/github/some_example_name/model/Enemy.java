package io.github.some_example_name.model;




import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import io.github.some_example_name.controller.PlayerController;
import io.github.some_example_name.model.GameAssetManger;

public class Enemy {
    private Animation<Texture> walkAnimation;
    private Texture texture;
    private Sprite sprite;
    private float worldX, worldY;
    private CollisionRect collisionRect;
    private int health = 25;
    private boolean isAlive = true;


    public Enemy(float x, float y) {
        this.worldX = x;
        this.worldY = y;
        Texture enemy0Tex = new Texture("TentacleIdle/TentacleIdle0.png");
        Texture enemy1Tex = new Texture("TentacleIdle/TentacleIdle1.png");
        Texture enemy2Tex = new Texture("TentacleIdle/TentacleIdle2.png");
        Texture enemy3Tex = new Texture("TentacleIdle/TentacleIdle3.png");
        walkAnimation = new Animation<>(0.1f, enemy0Tex, enemy1Tex, enemy2Tex, enemy3Tex);
        this.sprite = new Sprite(enemy0Tex);
        this.sprite.setSize(40, 40); // Adjust based on visual size
        this.sprite.setPosition(x, y);
        this.collisionRect = new CollisionRect(x, y, sprite.getWidth(), sprite.getHeight());
    }
    private float animationTimer = 0f;
    private boolean alive = true;
    private boolean dying = false;
    private float deathTimer = 0f;
    private float deathDuration = 0.8f; // Adjust as needed
    private Animation<Texture> deathAnimation = GameAssetManger.getGameAssetManager().getDeath_frame();

    public void updateDeathAnimation(float delta) {
        if (dying) {
            deathTimer += delta;
        }
    }

    public boolean isDying() {
        return dying;
    }

    public boolean shouldBeRemoved() {
        return !alive && deathTimer >= deathDuration;
    }

    public void die() {
        alive = false;
        dying = true;
        deathTimer = 0;
    }

    public void update(float delta) {
        animationTimer += delta;
    }

    public Texture getCurrentFrame() {
        return walkAnimation.getKeyFrame(animationTimer, true);
    }
    public Texture getCurrentDeathFrame() {
        return deathAnimation.getKeyFrame(deathTimer, false);
    }
    public void takeDamage(int amount) {
        this.health -= amount;
        if (health <= 0) {
            isAlive = false;
        }
    }

    public void setAlive(boolean alive) {
        isAlive = alive;
    }

    public void updateCollisionRect(Player player) {
        // Convert screen coords to world coords
        float worldX = sprite.getX() - Gdx.graphics.getWidth() / 2f + player.getPosX();
        float worldY = sprite.getY() - Gdx.graphics.getHeight() / 2f + player.getPosY();
        collisionRect.move(worldX, worldY);
    }


    public boolean isAlive() {
        return isAlive;
    }

    public CollisionRect getCollisionRect() {
        return collisionRect;
    }

    public Sprite getSprite() {
        return sprite;
    }

    public float getWorldX() {
        return worldX;
    }

    public float getWorldY() {
        return worldY;
    }

    public void dispose() {
        texture.dispose();
    }
}



