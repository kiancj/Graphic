package io.github.some_example_name.model;

import java.util.ArrayList;

public class App {
    private static Player currentPlayer;
    private static User currentUser;
    private static ArrayList<User> gameUsers = new ArrayList<>() ;
    public static Player getCurrentPlayer() {
        return currentPlayer;
    }

    public static void setCurrentPlayer(Player currentPlayer) {
        App.currentPlayer = currentPlayer;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        App.currentUser = currentUser;
    }

    public static void addUser(User user){
        gameUsers.add(user);
    }

    public static ArrayList<User> getGameUsers() {
        return gameUsers;
    }
    public static User findUserByUsername(String username){
        for(User user : App.getGameUsers()){
            if(user.getUsername().equals(username)){
                return user;
            }
        }
        return null;
    }
}
