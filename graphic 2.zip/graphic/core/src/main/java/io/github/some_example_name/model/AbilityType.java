package io.github.some_example_name.model;

public enum AbilityType {
    VITALITY("Vitality Boost"),
    DAMAGER("Damage Increase"),
    SPEEDY("Speed Boost"),
    PROCREASE("Projectile Speed"),
    AMOCREASE("Ammo Capacity");

    private final String displayName;

    AbilityType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}

