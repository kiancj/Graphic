package io.github.some_example_name.model;

public enum WeaponType {
    REVOLVER("Revolver", 20, 1, 1, 6),
    SHOTGUN("Shotgun", 10, 4, 1, 2),
    SMGS_DUAL("SMGs Dual", 8, 1, 2, 24);

    private final String name;
    private final int damage;
    private final int projectile;
    private final int reloadTimeInSeconds;
    private final int maxAmmo;

    WeaponType(String name, int damage, int projectile, int reloadTimeInSeconds, int maxAmmo) {
        this.name = name;
        this.damage = damage;
        this.projectile = projectile;
        this.reloadTimeInSeconds = reloadTimeInSeconds;
        this.maxAmmo = maxAmmo;
    }

    public String getName() {
        return name;
    }

    public int getDamage() {
        return damage;
    }

    public int getProjectile() {
        return projectile;
    }

    public int getReloadTimeInSeconds() {
        return reloadTimeInSeconds;
    }

    public int getMaxAmmo() {
        return maxAmmo;
    }

    @Override
    public String toString() {
        return name + " (Damage: " + damage +
            ", Projectiles: " + projectile +
            ", Reload: " + reloadTimeInSeconds + "s" +
            ", Ammo Max: " + maxAmmo + ")";
    }
}
