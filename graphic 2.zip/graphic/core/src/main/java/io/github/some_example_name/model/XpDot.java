package io.github.some_example_name.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class XpDot {
    private Sprite sprite;
    private boolean collected = false;
    private CollisionRect collisionRect;
    private float worldX, worldY;

    public XpDot(float x, float y) {
        Texture texture = new Texture(GameAssetManger.getGameAssetManager().getXpDot()); // XP dot asset
        this.worldX = x;
        this.worldY = y;
        this.sprite = new Sprite(texture);
        this.sprite.setSize(16, 16); // Adjust size as needed
        this.sprite.setPosition(x, y);
        this.collisionRect = new CollisionRect(x, y, 16, 16);
    }

    public void draw(SpriteBatch batch, float playerWorldX, float playerWorldY) {
        if (collected) return;
        // Convert world position to screen position
        float screenX = worldX - playerWorldX + Gdx.graphics.getWidth() / 2f;
        float screenY = worldY - playerWorldY + Gdx.graphics.getHeight() / 2f;

        sprite.setPosition(screenX, screenY);
        sprite.draw(batch);
        // DO NOT move collision rect to screen coords here!
    }

    public void updateCollisionRect() {
        collisionRect.move(worldX, worldY); // ✅ Use world position!
    }



    public float getWorldX() {
        return worldX;
    }

    public float getWorldY() {
        return worldY;
    }

    public CollisionRect getCollisionRect() {
        return collisionRect;
    }

    public boolean isCollected() {
        return collected;
    }

    public void collect() {
        collected = true;
    }
}
