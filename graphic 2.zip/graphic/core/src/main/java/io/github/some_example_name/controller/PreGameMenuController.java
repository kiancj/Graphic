package io.github.some_example_name.controller;

import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;
import io.github.some_example_name.view.GameView;
import io.github.some_example_name.view.PreGameMenuView;

public class PreGameMenuController {
    private PreGameMenuView view;
    private PreGame pregame;


    public void setView(PreGameMenuView view) {
        this.view = view;
        this.pregame = new PreGame();
    }

    public void handlePreGameMenuButtons(String hero , String weapon , String time)  {
        if (view != null) {
            App.setCurrentPlayer(new Player());
            Player player = App.getCurrentPlayer();
            switch (hero) {
                case "SHANA":
                    player.setPlayerHealth(Hero.SHANA.getHp());
                    player.setSpeed(Hero.SHANA.getSpeed());
                    player.setPlayerAnimation(GameAssetManger.getGameAssetManager().getCharacter1_idle_animation());
                    break;
                case "DIAMOND":
                    player.setPlayerHealth(Hero.DIAMOND.getHp());
                    player.setSpeed(Hero.DIAMOND.getSpeed());
                    player.setPlayerAnimation(GameAssetManger.getGameAssetManager().getCharacter2_run_frames());
                    break;
                case "SCARLET":
                    player.setSpeed(Hero.SCARLET.getSpeed());
                    player.setPlayerHealth(Hero.SCARLET.getHp());
                    player.setPlayerAnimation(GameAssetManger.getGameAssetManager().getCharacter3_run_frames());
                    break;
                case "LILITH":
                    player.setPlayerHealth(Hero.LILITH.getHp());
                    player.setSpeed(Hero.LILITH.getSpeed());
                    player.setPlayerAnimation(GameAssetManger.getGameAssetManager().getCharacter4_run_frames());
                    break;
                case "DASHER":
                    player.setPlayerHealth(Hero.DASHER.getHp());
                    player.setSpeed(Hero.DASHER.getSpeed());
                    player.setPlayerAnimation(GameAssetManger.getGameAssetManager().getCharacter5_run_frames());
                    break;
            }
            switch (weapon) {
                case "Revolver":
                    player.setWeaponType(WeaponType.REVOLVER);
                    break;
                case "Shotgun":
                    player.setWeaponType(WeaponType.SHOTGUN);
                    break;
                case "SMGs Dual":
                    player.setWeaponType(WeaponType.SMGS_DUAL);
                    break;
            }
            switch (time) {
                case "2 Minutes":
                    player.setTime(120f);
                    break;
                case "5 Minutes":
                    player.setTime(300f);
                    break;
                case "10 Minutes":
                    player.setTime(600f);
                    break;
                case "20 Minutes":
                    player.setTime(1200f);
                    break;
            }
            if(view.getPlayButton().isPressed()){
                Main.getMain().getScreen().dispose();
                Main.getMain().setScreen(new GameView(new GameController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
       }
    }
}
