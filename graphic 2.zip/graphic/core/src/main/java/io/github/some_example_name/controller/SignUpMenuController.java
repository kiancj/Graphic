package io.github.some_example_name.controller;

import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.*;
import io.github.some_example_name.view.LoginMenuView;
import io.github.some_example_name.view.MainMenuView;
import io.github.some_example_name.view.SignUpMenuView;

public class SignUpMenuController {
    private SignUpMenuView view;
    private Skin skin;

    public void setView(SignUpMenuView view , Skin skin) {
        this.view = view;
        this.skin = skin;
    }

    public void handleSignUpMenuButtons() {
        if (view != null) {
            if (view.getPlayButton().isPressed() && (view.getField1().getText() != null) && (view.getField().getText() != null) && (view.getField().getText() != null)) {
                String username = view.getField().getText();
                String password = view.getField1().getText();
                String schoolName = view.getField2().getText();
                if(App.findUserByUsername(username) != null){
                    view.getLabel1().setText("Username is already taken.");
                }
                else if(!password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")){
                    view.getLabel1().setText("Your password isn't strong.");
                }
                else{
                    User user = new User(username,password,schoolName);
                    UserSaveManager.saveUser(user);
                    App.addUser(user);
                    Main.getMain().getScreen().dispose();
                    Main.getMain().setScreen(new LoginMenuView(new LoginMenuController(), GameAssetManger.getGameAssetManager().getSkin()));

                }
            }
            else if(view.getPlayButton1().isPressed()){
                User user = new User("guest","","");
                App.setCurrentUser(user);
                Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
        }
    }
//    public static boolean isUserUnique(String newUsername, String filename) {
//        ObjectMapper mapper = new ObjectMapper();
//        try {
//            File file = new File(filename);
//            if (!file.exists()) return true; // No users yet
//
//            Player[] players = mapper.readValue(file, Player[].class);
//
//            for (Player player : players) {
//                if (player.getUsername().equalsIgnoreCase(newUsername)) {
//                    return false; // Username already exists
//                }
//            }
//            return true;
//        } catch (IOException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
    /**
     * Checks if a username is unique.
     * @return true if username is available, false if taken OR if errors occur
     */
//    public static boolean isUserUnique(String newUsername, String filename) {
//        if (newUsername == null || newUsername.trim().isEmpty()) {
//            return false; // Invalid input
//        }
//
//        File file = new File(filename);
//
//        try {
//            // Case 1: File doesn't exist or is empty
//            if (!file.exists() || file.length() == 0) {
//                return true;
//            }
//
//            ObjectMapper mapper = new ObjectMapper();
//            Player[] players = mapper.readValue(file, Player[].class);
//
//            // Case 2: Empty JSON array
//            if (players == null || players.length == 0) {
//                return true;
//            }
//
//            // Case 3: Check against existing usernames
//            String normalizedNewUsername = newUsername.trim().toLowerCase();
//            for (Player player : players) {
//                if (player.getUsername() != null &&
//                    player.getUsername().trim().toLowerCase().equals(normalizedNewUsername)) {
//                    return false; // Username exists
//                }
//            }
//            return true; // Username available
//
//        } catch (IOException e) {
//            // Case 4: File read/JSON parse errors
//            Gdx.app.error("SignUp", "Error checking username uniqueness", e);
//            return false; // Fail-safe (assume username exists)
//        }
//    }

}
