package io.github.some_example_name.controller;

import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.PreGame;
import io.github.some_example_name.model.User;
import io.github.some_example_name.view.ForgetPassMenuView;
import io.github.some_example_name.view.LoginMenuView;
import io.github.some_example_name.view.MainMenuView;
import io.github.some_example_name.view.PreGameMenuView;

public class ForgetPassController {
    private ForgetPassMenuView view;


    public void setView(ForgetPassMenuView view) {
        this.view = view;
    }

    public void handleForgetPassButton() {
        if (view.getPlayButton().isPressed()) {
            Main.getMain().getScreen().dispose();
            String username = view.getField().getText();
            String schoolName = view.getField1().getText();
            String newPass = view.getField2().getText();
            if(App.findUserByUsername(username) == null){
                view.getLabel().setText("Username not found.");
                return;
            }
            User user = App.findUserByUsername(username);
            if(!user.getSchoolName().equals(schoolName)){
                view.getLabel().setText("School name is incorrect.");
                return;
            }
            else if(!newPass.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")){
                view.getLabel().setText("Your password isn't strong.");
                return;
            }
            else{
                user.setPassword(newPass);
                Main.getMain().setScreen(new LoginMenuView(new LoginMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }

        }
    }
}
