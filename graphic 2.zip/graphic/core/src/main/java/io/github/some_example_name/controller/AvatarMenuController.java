package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Timer;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.view.AvatarMenuView;
import io.github.some_example_name.view.MainMenuView;
import io.github.some_example_name.view.ProfileMenuView;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class AvatarMenuController {
    private AvatarMenuView view;
    private boolean inProcess = false;

    private final FileHandle avatarDir = Gdx.files.local("assets/avatar/");

    public void setView(AvatarMenuView view) {
        this.view = view;
    }

    public Array<String> getAvatarNames() {
        Array<String> names = new Array<>();
        if (avatarDir.exists()) {
            FileHandle[] files = avatarDir.list();
            int count = 0;
            for (FileHandle file : files) {
                if (count++ >= 10) break;
                names.add(file.name());
            }
        }
        return names;
    }

    public void handleButtons() {
        if (view == null) return;

        if (view.getBackButton().isPressed()) {
            goToProfileMenu();
        }

        else if (view.getSubmitButton().isPressed() && !inProcess) {
            inProcess = true;
            FileHandle selectedFile = view.getSelectedAvatarFile();
            FileHandle targetFile = avatarDir.child(selectedFile.name());

            copyFile(selectedFile, targetFile);

            Timer.schedule(new Timer.Task() {
                @Override
                public void run() {
                    inProcess = false;
                    App.getCurrentUser().setAvatarAddress("avatar/" + selectedFile.name());
                    goToProfileMenu();
                }
            }, 0.1f);
        }

        else if (view.getSubmitLocalButton().isPressed()) {
            String path = "avatar/" + view.getAvatarOptions().getSelected();
            App.getCurrentUser().setAvatarAddress(path);
            goToProfileMenu();
        }
    }

    public void dragAndDropPath(String fullPath) {
        File sourceFile = new File(fullPath);
        FileHandle sourceHandle = new FileHandle(sourceFile);
        FileHandle targetFile = avatarDir.child(sourceHandle.name());

        copyFile(sourceHandle, targetFile);

        Timer.schedule(new Timer.Task() {
            @Override
            public void run() {
                inProcess = false;
                App.getCurrentUser().setAvatarAddress("avatar/" + sourceHandle.name());
                goToProfileMenu();
            }
        }, 0.1f);
    }

    private void copyFile(FileHandle source, FileHandle destination) {
        try {
            Files.copy(source.file().toPath(), destination.file().toPath(), StandardCopyOption.REPLACE_EXISTING);
            Gdx.app.log("Avatar", "Copied to: " + destination.path());
        } catch (IOException e) {
            Gdx.app.error("Avatar", "Failed to copy avatar file", e);
        }
    }

    private void goToProfileMenu() {
        Main.getMain().setScreen(
            new MainMenuView(
                new MainMenuController(),
                GameAssetManger.getGameAssetManager().getSkin()
            )
        );
    }
}
