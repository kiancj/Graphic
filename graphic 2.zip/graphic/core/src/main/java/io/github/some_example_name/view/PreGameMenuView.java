package io.github.some_example_name.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import io.github.some_example_name.Main;
import io.github.some_example_name.controller.PreGameMenuController;

public class PreGameMenuView implements Screen {
    private Stage stage;
    private final Label gameTitle;
    private final TextButton playButton;
    private final SelectBox selectHero;
    private final SelectBox selectWeapon;
    private final SelectBox selectGameTime;
    private final Label gameLength;
    private final Label weaponSelect;
    public Table table;
    private PreGameMenuController controller;

    public PreGameMenuView(PreGameMenuController controller, Skin skin) {
        this.gameTitle = new Label("Pregame Menu", skin);
        this.weaponSelect = new Label("Weapon",skin);
        this.selectHero = new SelectBox<>(skin);
        this.selectWeapon = new SelectBox<>(skin);
        this.selectGameTime = new SelectBox<>(skin);
        this.playButton = new TextButton("Play", skin);
        this.gameLength = new Label("Game Length",skin);
        this.table = new Table();
        this.controller = controller;
        controller.setView(this);
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        Array<String> hero = new Array<>();

        hero.add("SHANA");
        hero.add("DIAMOND");
        hero.add("SCARLET");
        hero.add("LILITH");
        hero.add("DASHER");
        selectHero.setItems(hero);
        Array<String> weapon = new Array<>();
        weapon.add("Revolver");
        weapon.add("Shotgun");
        weapon.add("SMGs Dual");
        selectWeapon.setItems(weapon);
        Array<String> gameTime = new Array<>();
        gameTime.add("2 Minutes");
        gameTime.add("5 Minutes");
        gameTime.add("10 Minutes");
        gameTime.add("20 Minutes");
        selectGameTime.setItems(gameTime);
        table.setFillParent(true);
        table.center();
        table.row().pad(10, 0 , 10 , 0);
        table.add(gameTitle);
        table.row().pad(10, 0 , 10 , 0);
        table.add(selectHero);
        table.row().pad(10, 0 , 10 , 0);
        table.add(weaponSelect);
        table.row().pad(10, 0 , 10 , 0);
        table.add(selectWeapon);
        table.row().pad(10, 0 , 10 , 0);
        table.add(gameLength);
        table.row().pad(10, 0 , 10 , 0);
        table.add(selectGameTime);
        table.row().pad(10, 0 , 10 , 0);
        table.add(playButton);

        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().begin();
        Main.getBatch().end();
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
        String weapon = selectWeapon.getSelected().toString();
        String hero = selectHero.getSelected().toString();
        String time = selectGameTime.getSelected().toString();
        controller.handlePreGameMenuButtons(hero , weapon , time);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public TextButton getPlayButton() {
        return playButton;
    }
}
