package io.github.some_example_name.model;


public class AvatarPathProvider {

    private String avatarPath;       // Current avatar path
    private String prevAvatarPath;   // Previously used avatar path

    public AvatarPathProvider() {
        this.avatarPath = "";
        this.prevAvatarPath = "";
    }

    public String getAvatarPath() {
        return avatarPath;
    }

    public void setAvatarPath(String newPath) {
        this.avatarPath = newPath;
    }

    public String getPrevAvatarPath() {
        return prevAvatarPath;
    }

    // Update the previous path to the current one
    public void setPrevAvatarPath() {
        this.prevAvatarPath = this.avatarPath;
    }

    // Optional helper: check if the avatar changed
    public boolean hasChanged() {
        return !avatarPath.equals(prevAvatarPath);
    }
}

