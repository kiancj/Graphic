package io.github.some_example_name.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.Player;
import io.github.some_example_name.model.User;
import io.github.some_example_name.view.*;

import java.io.File;
import java.io.IOException;

public class LoginMenuController {
    private LoginMenuView view;
    private Skin skin;

    public void setView(LoginMenuView view , Skin skin) {
        this.view = view;
        this.skin = skin;
    }

    public void handleMainMenuButtons() {

            if (view.getPlayButton2().isPressed() ) {
                Main.getMain().getScreen().dispose();
                Main.getMain().setScreen(new SignUpMenuView(new SignUpMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
            else if(view.getPlayButton().isPressed()){
                String username = view.getField().getText();
                String password = view.getField1().getText();
                User user = App.findUserByUsername(username);
                if(user == null){
                    view.getLabel().setText("User not found.");
                    return;
                }
                if(!password.equals(user.getPassword())){
                    view.getLabel().setText("Password is wrong.");
                    return;
                }
                else{
                    App.setCurrentUser(user);
                    Main.getMain().getScreen().dispose();
                    Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
                }
            }
            else if(view.getPlayButton1().isPressed()){
                Main.getMain().getScreen().dispose();
                Main.getMain().setScreen(new ForgetPassMenuView(new ForgetPassController(), GameAssetManger.getGameAssetManager().getSkin()));
            }
        }

}
