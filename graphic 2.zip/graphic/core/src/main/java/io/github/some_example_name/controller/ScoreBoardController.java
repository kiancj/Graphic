package io.github.some_example_name.controller;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.utils.Array;
import io.github.some_example_name.Main;
import io.github.some_example_name.model.App;
import io.github.some_example_name.model.GameAssetManger;
import io.github.some_example_name.model.User;
import io.github.some_example_name.view.LoginMenuView;
import io.github.some_example_name.view.MainMenuView;
import io.github.some_example_name.view.ScoreBoardView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ScoreBoardController {
    private final List<User> users;
    ScoreBoardView view;

    public void setView(ScoreBoardView view) {
        this.view = view;
    }

    public ScoreBoardController() {
        // Simulated user data; replace with real data retrieval logic
        this.users = App.getGameUsers();
    }
    public void handleButtons(String sortType){
        if(view.getButton().isPressed()){
            Main.getMain().getScreen().dispose();
            Main.getMain().setScreen(new MainMenuView(new MainMenuController(), GameAssetManger.getGameAssetManager().getSkin()));
        }
        if(sortType.equals("Kill")){
        List<User> users1 = getTopUsersSortedBy(byKills());
        editTable(users1);
        }
        else if(sortType.equals("Score")){
            List<User> users1 = getTopUsersSortedBy(byScore());
            editTable(users1);
        }
        else if(sortType.equals("Survive Time")){
            List<User> users1 = getTopUsersSortedBy(bySurvivalTime());
            editTable(users1);
        }
        else if(sortType.equals("Username")){
            List<User> users1 = getTopUsersSortedBy(byUsername());
            editTable(users1);
        }
    }

    public List<User> getTopUsersSortedBy(Comparator<User> comparator) {
        List<User> copy = new ArrayList<>(App.getGameUsers()); // Make a copy to avoid mutating original list
        copy.sort(comparator);
        return copy.subList(0, Math.min(10, copy.size())); // Return top 10
    }


    // Comparators
    public Comparator<User> byScore() {
        return (a, b) -> Integer.compare(b.getScore(), a.getScore());
    }

    public Comparator<User> byUsername() {
        return Comparator.comparing(User::getUsername);
    }

    public Comparator<User> byKills() {
        return (a, b) -> Integer.compare(b.getKills(), a.getKills());
    }

    public Comparator<User> bySurvivalTime() {
        return (a, b) -> Integer.compare(b.getMostTimeStayedAlive(), a.getMostTimeStayedAlive());
    }
    public void editTable(List<User> users){
        int index = 0;
        for(User user : users){
            index ++;
            switch(index){
                case 1:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser1().setColor(Color.GREEN);
                    }
                    view.getUser1().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                break;
                case 2:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser2().setColor(Color.GREEN);
                    }

                    view.getUser2().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 3:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser3().setColor(Color.GREEN);
                    }
                    view.getUser3().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 4:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser4().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser4().setColor(Color.WHITE);
                    }
                    view.getUser4().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 5:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser5().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser5().setColor(Color.WHITE);
                    }
                    view.getUser5().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 6:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser6().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser6().setColor(Color.WHITE);
                    }
                    view.getUser6().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 7:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser7().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser7().setColor(Color.WHITE);
                    }
                    view.getUser7().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 8:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser8().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser8().setColor(Color.WHITE);
                    }
                    view.getUser8().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 9:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser9().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser9().setColor(Color.WHITE);
                    }
                    view.getUser9().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
                case 10:
                    if(App.getCurrentUser().getUsername().equals(user.getUsername())){
                        view.getUser10().setColor(Color.GREEN);
                    }
                    else{
                        view.getUser10().setColor(Color.WHITE);
                    }
                    view.getUser10().setText(index+"."+user.getUsername()+" Score: "+user.getScore()+" Kills: "+user.getKills()+" Survive Time: "+user.getMostTimeStayedAlive());
                    break;
            }
        }
    }
}
